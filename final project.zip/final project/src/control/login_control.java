package control;
import java.awt.event.*;
import java.io.*;
import model.login;
import view.login_view;
import view.newUser_view;
import model.newUser;
import view.forgotPass_view;
import view.frame;
public class login_control {
login login;
login_view lv;
newUser_view uv;
newUser us;
public login_control(login login1,login_view lv1){
	login=login1;
	lv=lv1;
	lv.addNewUserListener(new AddUser());
	lv.addLoginListener(new AddLogin());
	lv.addForgotPassword(new ForgotPass());
}
class ForgotPass implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		forgotPass_view fv=new forgotPass_view();
		fv.setVisible(true);
		
	}
	
}
class AddUser implements ActionListener{
	public void actionPerformed(ActionEvent arg0) {
		uv=new newUser_view();
		uv.setVisible(true);
	uv.addBackListener(new Back());
	}
	} 
class Back implements ActionListener{

	public void actionPerformed(ActionEvent arg0) {
		lv.setVisible(true);
		uv.setVisible(false);
	}
	
}
class AddLogin implements ActionListener{

	public void actionPerformed(ActionEvent arg0) {
		newUser s=new newUser();
		try {
			ObjectInputStream x = new ObjectInputStream(new FileInputStream("List.ser"));
			while (true) {
				s = (newUser) x.readObject();
				if (s.getPassword().equals(lv.getPassword())&&s.getUsername().equals(lv.getUsername())) {
					frame f=new frame();
					f.setVisible(true);
					lv.setVisible(false);
					break;
				}
			}
		}catch(Exception e){
			return;
		}
	}
		
	}
	
}



