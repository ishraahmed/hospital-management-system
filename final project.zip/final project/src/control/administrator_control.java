package control;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import model.administrator;
import view.admin_delete;
import view.administrator_Edit;
import view.administrator_view;
import view.searchView_admin;
public class administrator_control {
administrator admin;
administrator_view av;
public String id;
public int id1;
String n;
public administrator_control(administrator admin1,administrator_view av1){
	admin=admin1;
	av=av1;
	av.AddAdminSave(new save());
	av.AddAdminSearch(new search());
	av.AddAdminEdit(new edit());
	av.AddAdminDelete(new delete());
}
class delete implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		admin_delete d=new admin_delete();
		d.setVisible(true);
	}
	
}
class edit implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		administrator_Edit ae=new administrator_Edit();
		ae.setVisible(true);
		
	}
	
}
class search implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		searchView_admin sa=new searchView_admin();
		sa.setVisible(true);
	}
	
}
class save implements ActionListener{

	public void actionPerformed(ActionEvent arg0) {
		ArrayList<administrator> adminList=readAllData();
		ObjectOutputStream outputStream=null;
//administrator(String name, String age, String gender, String dOB, String hD, 
		//String sT,String i,String num1,String address1,String education1)		
		String name,age,gender,dob,hd,bill,i,num,add,edu;
		name=av.getAdminName();
		age=av.getAdminAge();
		gender=av.getAdminGender();
		dob=av.getAdminDOB();
		hd=av.getAdminHireDate();
		bill=av.getAdminSalary();
		i=av.getAdminId();
		num=av.getAdminNumber();
		add=av.getAdminAddress();
		edu=av.getAdminEducation();
		administrator ad=new administrator( name,age,gender,dob,hd,bill,i,num,add,edu);
		try{
			//ArrayList<administrator> adminList=readAllData();
			adminList.add(ad);
			outputStream=new ObjectOutputStream(new FileOutputStream("admin.ser"));
			for(int u=0;u<adminList.size();u++){
				outputStream.writeObject(adminList.get(u));
			}
			JOptionPane.showMessageDialog(null,"Record Saved","information",JOptionPane.INFORMATION_MESSAGE);
		}
		catch(IOException e) {
			System.out.println("IO Exception while opening file");
		} finally { // cleanup code which closes output stream if its object was created
			try {
				if(outputStream != null) {
					outputStream.close();
					// flag of success
					
				}

			} catch (IOException e) {
				System.out.println("IO Exception while closing file");
			}
	}
		for(int in=0;in<adminList.size();in++){
			id=adminList.get(in).getId();
		}
		id1=Integer.parseInt(id)+1;
		//n=String.valueOf(id1);
		if(id==null)
			n="1";
		if(id!=null){
			n=String.valueOf(id1);
		}
		av.setAdminId(n);
		av.setAdminAddress(null);
		av.setAdminAge(null);
		av.setAdminDOB(null);
		av.setAdminEducation(null);
		av.setAdminHireDate(null);
		av.setAdminName(null);
		av.setAdminNumber(null);
		av.setAdminSalary(null);
	}
}
public ArrayList<administrator>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<administrator> adminList = new ArrayList<administrator>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("admin.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
administrator myObj = (administrator) inputStream.readObject();
// add object into ArrayList
adminList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return adminList;
}
}
