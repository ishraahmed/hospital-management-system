package control;
import view.admit_view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

import model.doctor;
import model.patient;
import view.patient_view;
import view.search_view;
public class patient_control {
patient pat;
patient_view pview;
public patient_control(patient p,patient_view pv){
	pat=p;
	pview=pv;
	pview.addPatientSave(new savePatient());
	pview.addSearchPatient(new search());
	pview.addAdmitListener(new Admit());
}
class Admit implements ActionListener{
	public void actionPerformed(ActionEvent arg0) {
		admit_view av=new admit_view();
		
	}
	
}
class search implements ActionListener{
	public void actionPerformed(ActionEvent arg0) {
	search_view sv=new search_view();
	sv.setVisible(true);
	
	}
	
}
class savePatient implements ActionListener{
public void actionPerformed(ActionEvent e) {
		ObjectOutputStream outputStream=null;
		String name,age,gender,dob,id,dov,consultant,consultantdep;
		name=pview.getName();
		age=pview.getAge();
		gender=pview.getGender();
		dob=pview.getDOB();
		id=pview.getId();
		dov=pview.getDOV();
		consultant=pview.getConsultant();
		consultantdep=pview.getConsultantDep();
		doctor d=new doctor(pview.getConsultant(),null,null,null,null,null,null,null,null,null,null,pview.getConsultantDep(),null,null);
		pat=new patient(name,age,gender,dob,id,dov,d,null,null,null,null,null,null);
		try {
			ArrayList<patient> patientList = readAllData();
			patientList.add(pat);
			outputStream = new ObjectOutputStream(new FileOutputStream("patient.ser"));
			for(int i = 0 ; i < patientList.size() ; i++) {
				outputStream.writeObject(patientList.get(i));
			}
			JOptionPane.showMessageDialog(null,"Record Saved!","information",JOptionPane.INFORMATION_MESSAGE);
			// ArrayList<patient> patientList = readAllData() ;
	            File file = new File("patient.ser");
	            
	            for(int i = 0 ; i<patientList.size() ; i++){
	                    id=patientList.get(i).getPatientId();
	                     }
	           int  id1=Integer.parseInt(id);
	            int num=id1+1;
	            String n=String.valueOf(num);
			pview.setPatientId(n);
			pview.setName(null);
			pview.setAge(null);
			pview.setDOB(null);
			pview.setDOV(null);
			pview.setConsultant(null);
			pview.setConsultantDep(null);
		} catch(IOException exp) {
			System.out.println("IO Exception while opening file");
		} finally { // cleanup code which closes output stream if its object was created
			try {
				if(outputStream != null) {
					outputStream.close();
					// flag of success
					
				}

			} catch (IOException exp) {
				System.out.println("IO Exception while closing file");
			}
		}
}
	
}
public ArrayList<patient>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<patient> patientList = new ArrayList<patient>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("patient.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
patient myObj = (patient) inputStream.readObject();
// add object into ArrayList
patientList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return patientList;
}
}

