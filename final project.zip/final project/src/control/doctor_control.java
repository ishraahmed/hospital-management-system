package control;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import view.searchView_doc;
import model.doctor;
import model.patient;
import view.doctor_view;
import view.searchView_doc;
public class doctor_control {
doctor doc;
doctor_view dv;
public String id;
public doctor_control(doctor doc1,doctor_view dv1){
	doc=doc1;
	dv=dv1;
     dv.AddDocSave(new Save());
     dv.AddDocSearch(new Search());
}
class Search implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		searchView_doc sv=new searchView_doc();
		sv.setVisible(true);
	}
	
}
class Save implements ActionListener{
	public void actionPerformed(ActionEvent arg0) {
		ObjectOutputStream outputStream=null;
		String name,age,gender,dob,docid,qualification,speciality,type,timings,dep,num,address,HD,St;
		name=dv.getDoctorName();
		age=dv.getDoctorAge();
		gender=dv.getDoctorGender();
		dob=dv.getDoctorDOB();
		docid=dv.getDoctorId();
		qualification=dv.getDoctorQualiiaction();
		speciality=dv.getDoctorSep();
		type=dv.getDoctorType();
		timings=dv.getDoctorTiming();
		address=dv.getDoctorAddress();
		dep=dv.getDoctorDep();
		num=dv.getDoctorNum();
		HD=dv.getDoctorHireDate();
		St=dv.getDoctorStaffType();
		doc=new doctor(name,age,gender,dob,HD,St,docid,qualification,speciality,type,timings,dep,num,address);
		try {
			ArrayList<doctor> doctorList = readAllData();
			doctorList.add(doc);
			outputStream = new ObjectOutputStream(new FileOutputStream("doctor.ser"));
			for(int i = 0 ; i < doctorList.size() ; i++) {
				outputStream.writeObject(doctorList.get(i));
			}
			JOptionPane.showMessageDialog(null,"record saved","information",JOptionPane.INFORMATION_MESSAGE);
			 File file = new File("doctor.ser");
	            
	            for(int i = 0 ; i<doctorList.size() ; i++){
	                    id=doctorList.get(i).getDocId();
	                     }
	           int  id1=Integer.parseInt(id);
	            int numm=id1+1;
	            String n=String.valueOf(numm);
			dv.setDoctorName(null);
			dv.setDoctorAge(null);
			dv.setDoctorDOB(null);
			dv.setDoctorId(n);
			dv.setDoctorQualiiaction(null);
			dv.setDoctorSep(null);
			dv.setDoctorTiming(null);
			dv.setDoctorAddress(null);
			dv.setDoctorDep(null);
			dv.setDoctorNum(null);
			dv.setDoctorHireDate(null);
			dv.setDoctorStaffType(null);
		} catch(IOException exp) {
			System.out.println("IO Exception while opening file");
		} finally { // cleanup code which closes output stream if its object was created
			try {
				if(outputStream != null) {
					outputStream.close();
					// flag of success
					
				}

			} catch (IOException exp) {
				System.out.println("IO Exception while closing file");
			}
		}
		
	}
	
}
public ArrayList<doctor>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<doctor> doctorList = new ArrayList<doctor>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("doctor.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
doctor myObj = (doctor) inputStream.readObject();
// add object into ArrayList
doctorList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return doctorList;
}
}
