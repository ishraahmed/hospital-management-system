package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import model.workers_staff;
import view.searchView_worker;
import view.workersStaff_del;
import view.workersStaff_view;
import view.workers_Edit;

public class workerStaff_control {
workers_staff ws;
workersStaff_view wv;
String id;
int id1;
String n;
public workerStaff_control(workers_staff ws1,workersStaff_view wv1){
	ws=ws1;
	wv=wv1;
	wv.addSaveWorker(new save());
	wv.addSearchWorker(new search());
	wv.addEditWorker(new edit());
	wv.addDeleteWorker(new delete());
}
class delete implements ActionListener{

	public void actionPerformed(ActionEvent arg0) {
		workersStaff_del wd=new workersStaff_del();
		// TODO Auto-generated method stub
		wd.setVisible(true);
	}
	
}
class edit implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		workers_Edit we=new workers_Edit();
		we.setVisible(true);
	}
	
}
class search implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		searchView_worker sw=new searchView_worker();
		sw.setVisible(true);
		
	}
	
}
class save implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		ArrayList workerList=readAllData();
		ObjectOutputStream outputStream=null;
		//workers_staff(String name, String age, String gender, 
		//String dOB, String hD, String sT,String i,String num1,
		//String address1,String education1,String type1)
		String name,age,gender,dob,hd,sal,id,num,add,edu,type;
		name=wv.getWorkerName();
		age=wv.getWorkerAge();
		gender=wv.getWorkerGender();
		dob=wv.getWorkerDOB();
		hd=wv.getWorkerHireDate();
		sal=wv.getWorkerSalary();
		id=wv.getWorkerId();
		num=wv.getWorkerNum();
		add=wv.getWorkerAddress();
		edu=wv.getWorkerEducation();
		type=wv.getWorkerStaffType();
		ws=new workers_staff(name,age,gender,dob,hd,sal,id,num,add,edu,type);
		try{
			outputStream=new ObjectOutputStream(new FileOutputStream("worker.ser"));
			workerList.add(ws);
		    for(int i=0;i<workerList.size();i++){
		    
		    	outputStream.writeObject(workerList.get(i));
		    	
		    }
		    JOptionPane.showMessageDialog(null,"Record Saved","information",JOptionPane.INFORMATION_MESSAGE);
		}
		catch(Exception exp){
			System.out.println("IO Exception while opening file");
		}
		finally{
			try {
				if(outputStream != null) {
					outputStream.close();
					// flag of success
					
				}

			} catch (IOException exp) {
				System.out.println("IO Exception while closing file");
			}
		}
		for(int i=0;i<workerList.size();i++){
			id=((workers_staff) workerList.get(i)).getId();
		}
		if(id==null){
			wv.setWorkerId("1");
		}
		if(id!=null){
			id1=Integer.parseInt(id)+1;
			n=String.valueOf(id1);
			wv.setWorkerId(n);
		}
		wv.setWorkerName(null);
		wv.setWorkerAddress(null);
		wv.setWorkerAge(null);
		wv.setWorkerDOB(null);
		wv.setWorkerEducation(null);
		wv.setWorkerHireDate(null);
		wv.setWorkerSalary(null);
		wv.setWorkerStaffType(null);
		wv.setWorkerNum(null);
	
	}
	
}
public ArrayList<workers_staff> readAllData(){
	ArrayList<workers_staff> workerList=new ArrayList<workers_staff>(0);
	ObjectInputStream inputStream=null;
	try{
		inputStream=new ObjectInputStream(new FileInputStream("worker.ser"));
		Boolean EOF=false;
		while(!EOF){
			try{
				workers_staff obj=(workers_staff)inputStream.readObject();
				workerList.add(obj);
				
			}
			catch (ClassNotFoundException e) {
				//System.out.println("Class not found");
				} catch (EOFException end) {
				// EOFException is raised when file ends
				// set End Of File flag to true so that loop exits
				EOF = true;
				}
		}
	}
	catch(FileNotFoundException e) {
		//System.out.println("Cannot find file");
		} catch (IOException e) {
		//System.out.println("IO Exception while opening stream");
		//e.printStackTrace();
		}finally { // cleanup code to close stream if it was opened
			try {
				if(inputStream != null)
				inputStream.close( );
				} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("IO Exception while closing file");
				}
				}
	return workerList;
}
}
