package control;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import model.technicalStaff;
import view.searchView_tech;
import view.technicalStaff_Edit;
import view.technicalStaff_del;
import view.technicalStaff_view;
public class technicalStaff_control {
technicalStaff ts;
technicalStaff_view tv;
String id;
int id1;
String n;
public technicalStaff_control(technicalStaff ts1,technicalStaff_view tv1){
	ts=ts1;
	tv=tv1;
	tv.AddTechSave(new save());
	tv.AddTechSearch(new search());
	tv.AddTechEdit(new edit());
	tv.AddTechDelete(new delete());
}
class delete implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
	technicalStaff_del td=new technicalStaff_del();
		td.setVisible(true);
	}
	
}
class edit implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		technicalStaff_Edit te=new technicalStaff_Edit();
		te.setVisible(true);
	}
	
}
class search implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		searchView_tech st=new searchView_tech();
		st.setVisible(true);
		
	}
	
}
class save implements ActionListener{
	public void actionPerformed(ActionEvent e) {
	ArrayList<technicalStaff> techList=readAllData();
	String name,age,gender,dob,hd,bill,id,num,add,edu;
	name=tv.getTechName();
	age=tv.getTechAge();
	gender=tv.getTechGender();
	dob=tv.getTechDOB();
	hd=tv.getTechHireDate();
	bill=tv.getTechSalary();
	id=tv.getTechId();
	num=tv.getTechNumber();
	add=tv.getTechAddress();
	edu=tv.getTechEducation();
	ts=new technicalStaff(name,age,gender,dob,hd,bill,id,num,add,edu);
	ObjectOutputStream outputStream=null;
	try{
		outputStream=new ObjectOutputStream(new FileOutputStream("tech.ser"));
		techList.add(ts);
		for(int i=0;i<techList.size();i++){
			outputStream.writeObject(techList.get(i));
			id=techList.get(i).getId();
		}
		JOptionPane.showMessageDialog(null,"Record Saved","information",JOptionPane.INFORMATION_MESSAGE);
		if(id!=null){
			id1=Integer.parseInt(id)+1;
			n=String.valueOf(id1);
			tv.setTechId(n);
		}
		if(id==null){
			tv.setTechId("1");
		}
		tv.setTechAddress(null);
		tv.setTechAge(null);
		tv.setTechDOB(null);
		tv.setTechEducation(null);
		tv.setTechHireDate(null);
		tv.setTechName(null);
		tv.setTechNumber(null);
		tv.setTechSalary(null);
	} catch(IOException exp) {
		System.out.println("IO Exception while opening file");
	} finally { // cleanup code which closes output stream if its object was created
		try {
			if(outputStream != null) {
				outputStream.close();
				// flag of success
				
			}

		} catch (IOException exp) {
			System.out.println("IO Exception while closing file");
		}
	}
	}
	
}
public ArrayList<technicalStaff>  readAllData()
{
  //  ArrayList initialized with size 0
ArrayList<technicalStaff> techList = new ArrayList<technicalStaff>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("tech.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
	technicalStaff myObj = (technicalStaff) inputStream.readObject();
// add object into ArrayList
techList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return techList;
}
}
