package view;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.doctor;
import model.patient;

public class doctor_Edit extends JFrame {
JLabel[] l=new JLabel[4];
JTextField[] f=new JTextField[4];
JTextField fg;
JButton b1;
JLabel l1;
JButton[] b=new JButton[4];
JLabel[] lb=new JLabel [22];
String name,age,gender,dob,hd,sal,docId,edu,sep,type,tim,dep,num1,add;
public doctor_Edit(){
	super("Doctor");
	setContentPane(new JLabel(new ImageIcon("image1.jpg")));
	b1=new JButton("Back");
	this.setLayout(new BorderLayout());
	JPanel panel=new JPanel();
	panel.setOpaque(false);
	lb[0]=new JLabel("                                    Doctor's Edit View");
	lb[0].setFont(new Font("ALGERIAN",Font.BOLD,35));
	l1=new JLabel("                                                                                                                          ");
	panel.add(lb[0]);
	panel.add(l1);
	panel .add(b1);
	for(int i=1;i<20;i++){
		lb[i]=new JLabel("  ");
	}
	
	JPanel p=new JPanel(new GridLayout(19,0));
	p.setOpaque(false);
	JPanel p1=new JPanel(new GridLayout(1,2));
	p1.setOpaque(false);
	JPanel p2=new JPanel(new GridLayout(1,2));
	p2.setOpaque(false);
	JPanel p3=new JPanel(new GridLayout(1,2));
	p3.setOpaque(false);
	JPanel p4=new JPanel(new GridLayout(1,2));
	p4.setOpaque(false);
	JPanel p11=new JPanel(new GridLayout(1,2));
	p11.setOpaque(false);
	JLabel lg=new JLabel("Enter Doctor's Id");
	lg.setFont(new Font("Serif",Font.BOLD,20));
	fg=new JTextField(10);
	p11.add(lg);
	p11.add(fg);
	JPanel p5=new JPanel();
	p5.setOpaque(false);
	JPanel p6=new JPanel();
	p6.setOpaque(false);
	JPanel p7=new JPanel(new GridLayout(1,3));
	p7.setOpaque(false);
	JPanel p8=new JPanel(new GridLayout(1,3));
	p8.setOpaque(false);
	JPanel p9=new JPanel(new GridLayout(1,3));
	p9.setOpaque(false);
	JPanel p10=new JPanel(new GridLayout(1,3));
	p10.setOpaque(false);
	l[0]=new JLabel("Change Timings");
    l[0].setFont(new Font("Serif",Font.BOLD,20));
    f[0]=new JTextField(10);
    l[1]=new JLabel("Change Phone NO");
    l[1].setFont(new Font("Serif",Font.BOLD,20));
    f[1]=new JTextField(10);
    l[2]=new JLabel("Change Address");
    l[2].setFont(new Font("Serif",Font.BOLD,20));
    f[2]=new JTextField(10);
    l[3]=new JLabel("Change Salary");
    l[3].setFont(new Font("Serif",Font.BOLD,20));
    f[3]=new JTextField(10);
    b[0]=new JButton("Save Changes");
    b[1]=new JButton("Save Changes");
    b[2]=new JButton("Save Changes");
    b[3]=new JButton("Save Changes");
    for(int i=12;i<21;i++){
    	lb[i]=new JLabel("                           ");
    }
    p10.add(lb[18]);
    p10.add(b[3]);
    p10.add(lb[19]);
    p9.add(lb[16]);
    p9.add(b[2]);
    p9.add(lb[17]);
    p8.add(lb[14]);
    p8.add(b[1]);
    p8.add(lb[15]);
    p7.add(lb[12]);
    p7.add(b[0]);
    p7.add(lb[13]);
    p1.add(l[2]);
    p1.add(f[2]);
    p2.add(l[1]);
    p2.add(f[1]);
    p3.add(l[0]);
    p3.add(f[0]);
    p4.add(l[3]);
    p4.add(f[3]);
    p.add(lb[20]);
    p.add(p11);
   p.add(lb[1]);
    p.add(p3);
    p.add(lb[2]);
    p.add(p7);
    p.add(lb[3]);
    p.add(p2);
    p.add(lb[4]);
    p.add(p8);
    p.add(lb[5]);
    p.add(p1);
    p.add(lb[6]);
    p.add(p9);
    p.add(lb[7]);
    p.add(p4);
    p.add(lb[8]);
    p.add(p10);
    p.add(lb[9]);
    for(int i=10;i<12;i++){
    	lb[i]=new JLabel("                                                                                                                    ");
    }
    p5.add(lb[10]);
    p6.add(lb[11]);
    this.add(p,BorderLayout.CENTER);
    this.add(panel,BorderLayout.NORTH);
    this.add(p5,BorderLayout.EAST);
    this.add(p6,BorderLayout.WEST);
    this.setSize(1350,720);
    validate();
    MyButton butt=new MyButton();
    b[0].addActionListener(butt);
    b[1].addActionListener(butt);
    b[2].addActionListener(butt);
    b[3].addActionListener(butt);
    b1.addActionListener(butt);
}
class MyButton implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1){
			dispose();
		}
		if(e.getSource()==b[0]){
		ArrayList<doctor> doctorList=readAllData();
		for(int i=0;i<doctorList.size();i++){
			if(doctorList.get(i).getDocId().equalsIgnoreCase(fg.getText())){
				//String name,age,gender,dob,hd,sal,docId,edu,sep,type,tim,dep,num1,add;
				name=doctorList.get(i).getName();
				age=doctorList.get(i).getAge();
				gender=doctorList.get(i).getGender();
				dob=doctorList.get(i).getDOB();
				hd=doctorList.get(i).getHireDate();
				sal=doctorList.get(i).getStaffType();
				docId=doctorList.get(i).getDocId();
				edu=doctorList.get(i).getEducation();
				sep=doctorList.get(i).getSpeciality();
				type=doctorList.get(i).getType();
				dep=doctorList.get(i).getDepartment();
				num1=doctorList.get(i).getNum();
				add=doctorList.get(i).getAddress();
				doctorList.remove(i);
			}
		}
		
		doctor doc=new doctor( name,age,gender,dob,hd,sal,docId,edu,sep,type,f[0].getText(),dep,num1,add);
		ObjectOutputStream outputStream=null;
		try {
			doctorList.add(doc);
			outputStream = new ObjectOutputStream(new FileOutputStream("doctor.ser"));
			for(int i = 0 ; i < doctorList.size() ; i++) {
				outputStream.writeObject(doctorList.get(i));
			}
			JOptionPane.showMessageDialog(null,"Changings saved","information",JOptionPane.INFORMATION_MESSAGE);
			f[0].setText(null);
			fg.setText(null);
		} catch(IOException exp) {
			System.out.println("IO Exception while opening file");
		} finally { // cleanup code which closes output stream if its object was created
			try {
				if(outputStream != null) {
					outputStream.close();
					// flag of success
					
				}

			} catch (IOException exp) {
				System.out.println("IO Exception while closing file");
			}
		}
		}
		if(e.getSource()==b[1]){
			ArrayList<doctor> doctorList=readAllData();
			for(int i=0;i<doctorList.size();i++){
				if(doctorList.get(i).getDocId().equalsIgnoreCase(fg.getText())){
					//String name,age,gender,dob,hd,sal,docId,edu,sep,type,tim,dep,num1,add;
					name=doctorList.get(i).getName();
					age=doctorList.get(i).getAge();
					gender=doctorList.get(i).getGender();
					dob=doctorList.get(i).getDOB();
					hd=doctorList.get(i).getHireDate();
					sal=doctorList.get(i).getStaffType();
					docId=doctorList.get(i).getDocId();
					edu=doctorList.get(i).getEducation();
					sep=doctorList.get(i).getSpeciality();
					type=doctorList.get(i).getType();
					dep=doctorList.get(i).getDepartment();
					//num1=doctorList.get(i).getNum();
					tim=doctorList.get(i).getTimings();
					add=doctorList.get(i).getAddress();
					doctorList.remove(i);
				}
			}
			
			doctor doc=new doctor( name,age,gender,dob,hd,sal,docId,edu,sep,type,tim,dep,f[1].getText(),add);
			ObjectOutputStream outputStream=null;
			try {
				doctorList.add(doc);
				outputStream = new ObjectOutputStream(new FileOutputStream("doctor.ser"));
				for(int i = 0 ; i < doctorList.size() ; i++) {
					outputStream.writeObject(doctorList.get(i));
				}
				JOptionPane.showMessageDialog(null,"Changings saved","information",JOptionPane.INFORMATION_MESSAGE);
				f[1].setText(null);
				fg.setText(null);
			} catch(IOException exp) {
				System.out.println("IO Exception while opening file");
			} finally { // cleanup code which closes output stream if its object was created
				try {
					if(outputStream != null) {
						outputStream.close();
						// flag of success
						
					}

				} catch (IOException exp) {
					System.out.println("IO Exception while closing file");
				}
			}
			
		}
		if(e.getSource()==b[2]){
			ArrayList<doctor> doctorList=readAllData();
			for(int i=0;i<doctorList.size();i++){
				if(doctorList.get(i).getDocId().equalsIgnoreCase(fg.getText())){
					//String name,age,gender,dob,hd,sal,docId,edu,sep,type,tim,dep,num1,add;
					name=doctorList.get(i).getName();
					age=doctorList.get(i).getAge();
					gender=doctorList.get(i).getGender();
					dob=doctorList.get(i).getDOB();
					hd=doctorList.get(i).getHireDate();
					sal=doctorList.get(i).getStaffType();
					docId=doctorList.get(i).getDocId();
					edu=doctorList.get(i).getEducation();
					sep=doctorList.get(i).getSpeciality();
					type=doctorList.get(i).getType();
					dep=doctorList.get(i).getDepartment();
					num1=doctorList.get(i).getNum();
					tim=doctorList.get(i).getTimings();
				//	add=doctorList.get(i).getAddress();
					doctorList.remove(i);
				}
			}
			
			doctor doc=new doctor( name,age,gender,dob,hd,sal,docId,edu,sep,type,tim,dep,num1,f[2].getText());
			ObjectOutputStream outputStream=null;
			try {
				doctorList.add(doc);
				outputStream = new ObjectOutputStream(new FileOutputStream("doctor.ser"));
				for(int i = 0 ; i < doctorList.size() ; i++) {
					outputStream.writeObject(doctorList.get(i));
				}
				JOptionPane.showMessageDialog(null,"Changings saved","information",JOptionPane.INFORMATION_MESSAGE);
				f[2].setText(null);
				fg.setText(null);
			} catch(IOException exp) {
				System.out.println("IO Exception while opening file");
			} finally { // cleanup code which closes output stream if its object was created
				try {
					if(outputStream != null) {
						outputStream.close();
						// flag of success
						
					}

				} catch (IOException exp) {
					System.out.println("IO Exception while closing file");
				}
			}
		}
		if(e.getSource()==b[3]){
			ArrayList<doctor> doctorList=readAllData();
			for(int i=0;i<doctorList.size();i++){
				if(doctorList.get(i).getDocId().equalsIgnoreCase(fg.getText())){
					//String name,age,gender,dob,hd,sal,docId,edu,sep,type,tim,dep,num1,add;
					name=doctorList.get(i).getName();
					age=doctorList.get(i).getAge();
					gender=doctorList.get(i).getGender();
					dob=doctorList.get(i).getDOB();
					hd=doctorList.get(i).getHireDate();
					//sal=doctorList.get(i).getStaffType();
					docId=doctorList.get(i).getDocId();
					edu=doctorList.get(i).getEducation();
					sep=doctorList.get(i).getSpeciality();
					type=doctorList.get(i).getType();
					dep=doctorList.get(i).getDepartment();
					num1=doctorList.get(i).getNum();
					tim=doctorList.get(i).getTimings();
					add=doctorList.get(i).getAddress();
					doctorList.remove(i);
				}
			}
			
			doctor doc=new doctor( name,age,gender,dob,hd,f[3].getText(),docId,edu,sep,type,tim,dep,num1,add);
			ObjectOutputStream outputStream=null;
			try {
				doctorList.add(doc);
				outputStream = new ObjectOutputStream(new FileOutputStream("doctor.ser"));
				for(int i = 0 ; i < doctorList.size() ; i++) {
					outputStream.writeObject(doctorList.get(i));
				}
				JOptionPane.showMessageDialog(null,"Changings saved","information",JOptionPane.INFORMATION_MESSAGE);
				f[3].setText(null);
				fg.setText(null);
			} catch(IOException exp) {
				System.out.println("IO Exception while opening file");
			} finally { // cleanup code which closes output stream if its object was created
				try {
					if(outputStream != null) {
						outputStream.close();
						// flag of success
						
					}

				} catch (IOException exp) {
					System.out.println("IO Exception while closing file");
				}
			}
		}
	}
	
} 
public ArrayList<doctor>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<doctor> doctorList = new ArrayList<doctor>(0);
//Input stream
ObjectInputStream inputStream = null;
try
{
//open file for reading
inputStream = new ObjectInputStream(new FileInputStream("doctor.ser"));
//End Of File flag
boolean EOF = false;
//Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
doctor myObj = (doctor) inputStream.readObject();
// add object into ArrayList
doctorList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
//TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
//returns ArrayList
return doctorList;
}
}