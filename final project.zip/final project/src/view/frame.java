package view;
import model.administrator;
import model.doctor;
import model.login;
import javax.swing.*;
import control.patient_control;
import control.technicalStaff_control;
import control.workerStaff_control;
import view.doctor_view;
import control.administrator_control;
import control.doctor_control;
import model.patient;
import model.technicalStaff;
import model.workers_staff;

//import view.administrator_view;
import java.awt.*;
import java.awt.event.*;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import control.login_control;
public class frame extends JFrame {
JLabel l;
JButton b;
JButton b1;
JButton b2;
JButton b3;
JButton b4;
JButton b5;
JButton b6;
 String id;
int id1;
String n;
JLabel[] lb=new JLabel[21];
public frame(){
	super("Home");
	setContentPane(new JLabel(new ImageIcon("image1.jpg")));
	this.setLayout(new BorderLayout());
	l=new JLabel("                                     Select the category               ");
	JLabel l9=new JLabel("                                        ");
	l.setFont(new Font("ALGERIAN",Font.BOLD,35));
	b=new JButton("PATIENT");
	b4=new JButton("DOCTOR");
	b1=new JButton("TECHNICAL STAFF");
	b2=new JButton("ADMINISTRATION STAFF");
	b3=new JButton("WORKERS STAFF");
	b5=new JButton("Back");
	b6=new JButton("Logout");	
	JPanel p=new JPanel(new GridLayout());
	JPanel p1=new JPanel();
	JPanel p2=new JPanel(new GridLayout(5,5));
	JPanel p3=new JPanel(new GridLayout(0,2));
	JPanel p4=new JPanel(new GridLayout(0,2));
	p.setOpaque(false);
	p1.setOpaque(false);
	p2.setOpaque(false);
	p3.setOpaque(false);
	p4.setOpaque(false);
	//setContentPane(new JLabel(new ImageIcon("image1.jpg")));
	p1.add(l);
	p1.add(l9);
	p1.add(b5);
	p1.add(b6);
	for(int i=0;i<21;i++){
		lb[i]=new JLabel(" ");
	}
	for(int i=0;i<5;i++){
		p2.add(lb[i]);
	}
	p2.add(b);
	p2.add(lb[5]);
	p2.add(b4);
	p2.add(lb[6]);
	p2.add(b3);
	for(int i=7;i<13;i++){
		p2.add(lb[i]);
	}
	p2.add(b1);
	p2.add(lb[13]);
	p2.add(b2);
	for(int i=14;i<20;i++){
		p2.add(lb[i]);
	}

	this.add(p2,BorderLayout.CENTER);
	JLabel lp4=new JLabel("                          ");
	p4.add(lp4);
	this.add(p4,BorderLayout.WEST);
	JLabel lp=new JLabel("                            ");
	p3.add(lp);
	this.add(p3,BorderLayout.EAST);
	
	this.add(p1,BorderLayout.NORTH);
	this.setSize(1350,720);
	validate();
	MyButton butt=new MyButton();
	b.addActionListener(butt);
	b1.addActionListener(butt);
	b2.addActionListener(butt);
	b3.addActionListener(butt);
	b4.addActionListener(butt);
	b5.addActionListener(butt);
	b6.addActionListener(butt);
	validate();
}
class MyButton implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b3){
			dispose();
			workers_staff ws=new workers_staff();
			workersStaff_view wv=new workersStaff_view();
			workerStaff_control wc=new workerStaff_control(ws,wv);
			ArrayList<workers_staff> workerList=readAllData3();
			for(int i=0;i<workerList.size();i++){
				id=workerList.get(i).getId();
			}
			if(id==null)
				wv.setWorkerId("1");
			if(id!=null){
				id1=Integer.parseInt(id)+1;
				n=String.valueOf(id1);
				wv.setWorkerId(n);
			}
			wv.setVisible(true);
		}
		if(e.getSource()==b1){
			dispose();
			technicalStaff t=new technicalStaff();
			technicalStaff_view tv=new technicalStaff_view();
			technicalStaff_control tc=new technicalStaff_control(t,tv);
			ArrayList<technicalStaff> techList=readAllData2();
			for(int i=0;i<techList.size();i++){
				id=techList.get(i).getId();
			}
			if(id!=null){
	            id1=Integer.parseInt(id);
	            int num=id1+1;
	            n=String.valueOf(num);
	            }
	            if(id==null){
	            	n=String.valueOf(1);
	            }
	            tv.setTechId(n);
			tv.setVisible(true);
		}
		if(e.getSource()==b){
			patient pat=new patient();
			patient_view pview=new patient_view();
			patient_control pc=new patient_control(pat,pview);
			 ArrayList<patient> patientList = readAllData() ;
	            File file = new File("patient.ser");
	            
	            for(int i = 0 ; i<patientList.size() ; i++){
	                    id=patientList.get(i).getPatientId();
	                     }
	            if(id!=null){
	            id1=Integer.parseInt(id);
	            int num=id1+1;
	            n=String.valueOf(num);
	            }
	            if(id==null){
	            	n=String.valueOf(1);
	            }
            pview.setPatientId(n);
			pview.setVisible(true);
			dispose();
		}
		if(e.getSource()==b2){
			dispose();
			administrator admin=new administrator(); 
			administrator_view av=new administrator_view();
			administrator_control ac=new administrator_control(admin,av);
			ArrayList<administrator> adminList=readAllData1();
			for(int i=0;i<adminList.size();i++){
				id=adminList.get(i).getId();
			}
			if(id!=null){
	            id1=Integer.parseInt(id);
	            int num=id1+1;
	            n=String.valueOf(num);
	            }
	            if(id==null){
	            	n=String.valueOf(1);
	            }
	            av.setAdminId(n);
			av.setVisible(true);
			
		}
		if(e.getSource()==b4){
		doctor doc=new doctor();
		doctor_view dv=new doctor_view();
		doctor_control dc=new doctor_control(doc,dv);
		ArrayList<doctor> doctorList = ReadAllData() ;
        File file = new File("doctor.ser");
        
        for(int i = 0 ; i<doctorList.size() ; i++){
                id=doctorList.get(i).getDocId();
                 }
        if(id!=null){
        id1=Integer.parseInt(id);
        int num=id1+1;
        n=String.valueOf(num);}
        if(id==null){
        	n=String.valueOf(1);
        }
    dv.setDoctorId(n);
		dv.setVisible(true);
		dispose();
		}
		
		if(e.getSource()==b5){
			login l=new login();
			login_view lv=new login_view();
			login_control lc=new login_control(l,lv);
			lv.setVisible(true);
			dispose();
		}
		if(e.getSource()==b6){
			login l=new login();
			login_view lv=new login_view();
			login_control lc=new login_control(l,lv);
			lv.setVisible(true);
			dispose();
		}
		
	}
	
}
public ArrayList<patient>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<patient> patientList = new ArrayList<patient>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("patient.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
patient myObj = (patient) inputStream.readObject();
// add object into ArrayList
patientList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return patientList;
}
public ArrayList<doctor>  ReadAllData()
{
  //  ArrayList initialized with size 0
ArrayList<doctor> doctorList = new ArrayList<doctor>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("doctor.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
doctor myObj = (doctor) inputStream.readObject();
// add object into ArrayList
doctorList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return doctorList;
}
public ArrayList<administrator>  readAllData1()
{
  //  ArrayList initialized with size 0
ArrayList<administrator> adminList = new ArrayList<administrator>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("admin.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
administrator myObj = (administrator) inputStream.readObject();
// add object into ArrayList
adminList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return adminList;
}
public ArrayList<technicalStaff>  readAllData2()
{
  //  ArrayList initialized with size 0
ArrayList<technicalStaff> techList = new ArrayList<technicalStaff>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("tech.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
	technicalStaff myObj = (technicalStaff) inputStream.readObject();
// add object into ArrayList
techList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return techList;
}
public ArrayList<workers_staff> readAllData3(){
	ArrayList<workers_staff> workerList=new ArrayList<workers_staff>(0);
	ObjectInputStream inputStream=null;
	try{
		inputStream=new ObjectInputStream(new FileInputStream("worker.ser"));
		Boolean EOF=false;
		while(!EOF){
			try{
				workers_staff obj=(workers_staff)inputStream.readObject();
				workerList.add(obj);
				
			}
			catch (ClassNotFoundException e) {
				//System.out.println("Class not found");
				} catch (EOFException end) {
				// EOFException is raised when file ends
				// set End Of File flag to true so that loop exits
				EOF = true;
				}
		}
	}
	catch(FileNotFoundException e) {
		//System.out.println("Cannot find file");
		} catch (IOException e) {
		//System.out.println("IO Exception while opening stream");
		//e.printStackTrace();
		}finally { // cleanup code to close stream if it was opened
			try {
				if(inputStream != null)
				inputStream.close( );
				} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("IO Exception while closing file");
				}
				}
	return workerList;
}
}
