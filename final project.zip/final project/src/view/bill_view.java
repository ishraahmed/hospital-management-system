package view;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.*;

import model.doctor;
import model.patient;
public class bill_view extends JFrame {
JLabel[] l=new JLabel[23];
JTextField[] f=new JTextField[3];
JButton b;
public String name,age,gender,dob,patId,dov,consultant,consultantdep,doa,room,ward,bed,bill,dis;
bill_view(){
	super("Patient");
	setContentPane(new JLabel(new ImageIcon("img5.jpg")));
	l[0]=new JLabel("Discharge Date");
	l[0].setFont(new Font("Serif",Font.BOLD,20));
	f[0]=new JTextField(10);
	l[1]=new JLabel("Bill");
	l[1].setFont(new Font("Serif",Font.BOLD,20));
	f[1]=new JTextField(10);
	l[21]=new JLabel("Patient's Id");
	l[21].setFont(new Font("Serif",Font.BOLD,20));
	f[2]=new JTextField(10);
	/*[22]=new JLabel("Bill");
	l[22].setFont(new Font("Serif",Font.BOLD,20));
	f[22]=new JTextField(10);*/
	for(int i=2;i<5;i++){
		l[i]=new JLabel("  ");
	}
	for(int i=7;i<19;i++){
		l[i]=new JLabel("  ");
	}
	l[5]=new JLabel("                      ");
	l[6]=new JLabel("                      ");
	 b=new JButton("Save");
	 JPanel p=new JPanel(new GridLayout(9,2));
	 p.setOpaque(false);
	 p.add(l[2]);
	 p.add(l[3]);
	 p.add(l[21]);
	 p.add(f[2]);
	 p.add(l[13]);
	 p.add(l[14]);
	 p.add(l[0]);
	 p.add(f[0]);
	 p.add(l[7]);
	 p.add(l[8]);
	 p.add(l[11]);
	 p.add(l[12]);
	 p.add(l[1]);
	 p.add(f[1]);
	 p.add(l[9]);
	 p.add(l[10]);
	 p.add(l[15]);
	 p.add(l[16]);
	 JPanel p1=new JPanel(new GridLayout(3,1));
	 JPanel p2=new JPanel(new GridLayout(1,3));
	 p1.setOpaque(false);
	 p2.setOpaque(false);
	 l[19]=new JLabel("       ");
	 l[20]=new JLabel("       ");
	 p2.add(l[19]);
	 p2.add(b);
	 p2.add(l[20]);
	 p1.add(p2);
	 p1.add(l[17]);
	 p1.add(l[18]);
     this.setLayout(new BorderLayout());
     this.add(p,BorderLayout.CENTER);
     this.add(p1,BorderLayout.SOUTH);
     this.add(l[5],BorderLayout.EAST);
     this.add(l[6],BorderLayout.WEST);
     this.setSize(500,500);
     MyButton butt=new MyButton();
     b.addActionListener(butt);
}
class MyButton implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b){
			   ArrayList<patient> patientList = readAllData() ;
	            File file = new File("patient.ser");
	            
	            for(int i = 0 ; i<patientList.size() ; i++){
	            	if(patientList.get(i).getPatientId().equalsIgnoreCase(f[2].getText()))
	            	{
	                    name=patientList.get(i).getName();
	                    age=patientList.get(i).getAge();
	                    gender=patientList.get(i).getGender();
	                    dob=patientList.get(i).getDOB();
	                    patId=patientList.get(i).getPatientId();
	                    dov=patientList.get(i).getDOV();
	                    consultant=patientList.get(i).getConsultant();
	                    consultantdep=patientList.get(i).getConsultantdep();
	                    doa=patientList.get(i).getDOA();
	                    ward=patientList.get(i).getWard();
	                    room=patientList.get(i).getRoom();
	                    bed=patientList.get(i).getBed();
	            		patientList.remove(i);
	            	}
	            
	            }
	            doctor d=new doctor(consultant,null,null,null,null,null,null,null,null,null,null,consultantdep,null,null);
	            patient pat=new patient(name,age,gender,dob,patId,dov,d,doa,room,ward,bed,f[1].getText(),f[0].getText());
	            try {
			patientList.add(pat);
					ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
					for(int i = 0 ; i<patientList.size() ; i++){
						out.writeObject(patientList.get(i));
					}
					JOptionPane.showMessageDialog(new JFrame(),"Bill Added Successfully!");
					f[0].setText(null);
					f[1].setText(null);
					f[2].setText(null);
		            }
					
	             catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
		
	}
	
}
public ArrayList<patient>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<patient> patientList = new ArrayList<patient>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("patient.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
patient myObj = (patient) inputStream.readObject();
// add object into ArrayList
patientList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return patientList;
}
}
