package view;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.*;

import model.doctor;
public class doctor_delete extends JFrame {
JLabel l;
JTextField f;
JButton b;
JLabel l1;
JLabel[] lp=new JLabel[7];
doctor_delete(){
	super("Doctor");
	setContentPane(new JLabel(new ImageIcon("image5.jpg")));
	l=new JLabel("Enter doctor Id:");
	l.setFont(new Font("Serif",Font.BOLD,20));
	l1=new JLabel("Delete Doctor");
	l1.setFont(new Font("ALGERIAN",Font.BOLD,30));
	f=new JTextField(10);
	b=new JButton("Delete");
	for(int i=0;i<3;i++){
		lp[i]=new JLabel("  ");
	}
	lp[5]=new JLabel("    ");
	lp[6]=new JLabel("    ");
	JPanel p=new JPanel(new GridLayout(8,1));
	
	p.setOpaque(false);
	JPanel p1=new JPanel();
	p1.setOpaque(false);
	p1.add(l1);
	p.add(lp[5]);
	p.add(l);
	p.add(f);
	p.add(lp[0]);
	p.add(b);
	p.add(lp[1]);
	p.add(lp[2]);
	p.add(lp[6]);
	lp[3]=new JLabel("                                     ");
	lp[4]=new JLabel("                                     ");
	this.setLayout(new BorderLayout());
	this.add(p,BorderLayout.CENTER);
	this.add(p1,BorderLayout.NORTH);
	this.add(lp[3],BorderLayout.EAST);
	this.add(lp[4],BorderLayout.WEST);
	this.setSize(500, 500);
	MyButton butt=new MyButton();
	b.addActionListener(butt);
}
class MyButton implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b){
			  ArrayList<doctor> doctorList = readAllData() ;
	            File file = new File("doctor.ser");
	            String id =f.getText();
	            
	            for(int i = 0 ; i<doctorList.size() ; i++){
	            	if(doctorList.get(i).getDocId().equalsIgnoreCase(id))
	            	{
	            		doctorList.remove(i);
	            		JOptionPane.showMessageDialog(new JFrame(),"Succesfully Deleted!");
	            	}
	            f.setText(null);
	                    }
	            try {
					ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
					for(int i = 0 ; i<doctorList.size() ; i++){
						out.writeObject(doctorList.get(i));
					}
		            }
					
	             catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

		}
	}
	
}
public ArrayList<doctor>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<doctor> doctorList = new ArrayList<doctor>(0);
//Input stream
ObjectInputStream inputStream = null;
try
{
//open file for reading
inputStream = new ObjectInputStream(new FileInputStream("doctor.ser"));
//End Of File flag
boolean EOF = false;
//Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
doctor myObj = (doctor) inputStream.readObject();
// add object into ArrayList
doctorList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
//TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
//returns ArrayList
return doctorList;
}
}
