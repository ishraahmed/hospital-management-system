package view;
import control.login_control;
import model.doctor;
import model.login;
import model.patient;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
public class doctor_view extends JFrame{
	String n;
	JLabel p;
	JTextField f;
	JLabel p1;
	JTextField f1;
	JLabel p2;
	JTextField f2;
	JLabel p3;
	JTextField f3;
	JLabel p4;
	JTextField f4;
	JLabel p5;
	JTextField f5;
	JLabel p6;
	JTextField f6;
	JLabel p7;
	JTextField f7;
	JLabel p8;
	JTextField f8;
	JLabel p9;
	JTextField f9;
	JLabel p10;
	JTextField f10;
	JLabel p11;
	JTextField f11;
	JLabel p12;
	JTextField f12;
	JLabel p13;
	JTextField f13;
	JLabel[] lp=new JLabel[40];
	JRadioButton[] r=new JRadioButton[4];
	ButtonGroup g=new ButtonGroup();
	ButtonGroup g1=new ButtonGroup();
	JButton b;
	JButton b1;
	JButton b2;
	JButton b3;
	JButton b4;
	JButton b5;
	JButton b6;
	JLabel ly;
	public doctor_view(){
		super("Doctor");
		setContentPane(new JLabel(new ImageIcon("image1.jpg")));
		b=new JButton("Save");
		b1=new JButton("Search");
		b2=new JButton("Edit");
		b3=new JButton("Delete");
		r[0]=new JRadioButton("male",true);
		r[1]=new JRadioButton("female",false);
		r[2]=new JRadioButton("indoor",true);
		r[3]=new JRadioButton("outdoor",false);
		p=new JLabel("                          Doctor Id");
		p.setFont(new Font("Serif",Font.BOLD,20));
		p1=new JLabel("                             Name");
		p1.setFont(new Font("Serif",Font.BOLD,20));
		p2=new JLabel("                         Age");
		p2.setFont(new Font("Serif",Font.BOLD,20));
	p3=new JLabel("                             Gender");
		p3.setFont(new Font("Serif",Font.BOLD,20));
		p4=new JLabel("                         Date of Birth");
		p4.setFont(new Font("Serif",Font.BOLD,20));
		p5=new JLabel("                             Department");
		p5.setFont(new Font("Serif",Font.BOLD,20));
		p6=new JLabel("                         Timings");
		p6.setFont(new Font("Serif",Font.BOLD,20));
		p7=new JLabel("                             Speciality");
		p7.setFont(new Font("Serif",Font.BOLD,20));
		p8=new JLabel("                         Qualification");
		p8.setFont(new Font("Serif",Font.BOLD,20));
		p9=new JLabel("                             Indoor/Outdoor");
		p9.setFont(new Font("Serif",Font.BOLD,20));
		p10=new JLabel("                        Phone num");
		p10.setFont(new Font("Serif",Font.BOLD,20));
		p11=new JLabel("                            Address");
		p11.setFont(new Font("Serif",Font.BOLD,20));
		p12=new JLabel("                        Hire Date");
		p12.setFont(new Font("Serif",Font.BOLD,20));
		p13=new JLabel("                            Salary");
		p13.setFont(new Font("Serif",Font.BOLD,20));
		ly=new JLabel("                                  Doctor's Record");
		ly.setFont(new Font("ALGERIAN",Font.BOLD,35));
		JLabel lab=new JLabel("                                                                       ");
		b4=new JButton("Logout");
		b5=new JButton("Home");
		b6=new JButton("Back");
		f=new JTextField(10);
		f1=new JTextField(10);
		f2=new JTextField(10);
		//f3=new JTextField(10);
		f4=new JTextField(10);
		f5=new JTextField(10);
		f6=new JTextField(10);
		f7=new JTextField(10);
		f8=new JTextField(10);
		//f9=new JTextField(10);
		f10=new JTextField(10);
		f11=new JTextField(10);
		f12=new JTextField(10);
		f13=new JTextField(10);
		for(int i=0;i<40;i++){
			lp[i]=new JLabel("  ");
		}
		lp[36]=new JLabel("                              " );
		lp[37]=new JLabel("          " );
		this.setLayout(new BorderLayout());
		JPanel panel=new JPanel(new GridLayout(15,4));
		panel.setOpaque(false);
		JPanel pp=new JPanel();
		pp.setOpaque(false);
		JPanel pp1=new JPanel();
		pp1.setOpaque(false);
		JPanel pp2=new JPanel();
		pp2.setOpaque(false);
		JPanel pp3=new JPanel();
		pp3.setOpaque(false);
		JPanel pp4=new JPanel();
		pp4.setOpaque(false);
		JPanel pp5=new JPanel();
		pp5.setOpaque(false);
		g.add(r[0]);
		g.add(r[1]);
		g1.add(r[2]);
		g1.add(r[3]);
		pp4.add(r[0]);
		pp4.add(r[1]);
		pp5.add(r[2]);
		pp5.add(r[3]);
		pp2.add(lp[36]);
		pp3.add(lp[37]);
		pp1.add(ly);
		pp1.add(lab);
		pp1.add(b4);
		pp1.add(b5);
		pp1.add(b6);
		//JButton butt1=new JButton("yoo");
		for(int i=0;i<4;i++){
			panel.add(lp[i]);
		}
		panel.add(p);
		panel.add(f);
		panel.add(p1);
		panel.add(f1);
		for(int i=4;i<8;i++){
			panel.add(lp[i]);
		}
		panel.add(p2);
		panel.add(f2);
		panel.add(p3);
		panel.add(pp4);
		for(int i=8;i<12;i++){
			panel.add(lp[i]);
		}
		panel.add(p4);
		panel.add(f4);
		panel.add(p5);
		panel.add(f5);
		for(int i=12;i<16;i++){
			panel.add(lp[i]);
		}
		panel.add(p6);
		panel.add(f6);
		panel.add(p7);
		panel.add(f7);
		for(int i=16;i<20;i++){
			panel.add(lp[i]);
		}
		panel.add(p8);
		panel.add(f8);
		panel.add(p9);
		panel.add(pp5);
		for(int i=20;i<24;i++){
			panel.add(lp[i]);
		}
		panel.add(p10);
		panel.add(f10);
		panel.add(p11);
		panel.add(f11);
		for(int i=24;i<28;i++){
			panel.add(lp[i]);
		}
	
		panel.add(p12);
		panel.add(f12);
		panel.add(p13);
		panel.add(f13);
		for(int i=28;i<32;i++){
			panel.add(lp[i]);
		}
		pp.add(b);
		pp.add(b1);
		pp.add(b2);
		pp.add(b3);
		this.add(panel,BorderLayout.CENTER);
		this.add(pp,BorderLayout.SOUTH);
		this.add(pp1,BorderLayout.NORTH);
		this.add(pp2,BorderLayout.EAST);
		this.add(pp3,BorderLayout.WEST);
		this.setSize(1350,720);
		this.setVisible(true);
		MyButton butt=new MyButton();
		b3.addActionListener(butt);
		b2.addActionListener(butt);
		b4.addActionListener(butt);
		b5.addActionListener(butt);
		b6.addActionListener(butt);
		}
	class MyButton implements ActionListener{

		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==b2){
				doctor_Edit ed=new doctor_Edit();
				ed.setVisible(true);
			}
			if(e.getSource()==b5){
				dispose();
				frame f=new frame();
				f.setVisible(true);
			}
			if(e.getSource()==b6){
				dispose();
				frame f=new frame();
				f.setVisible(true);
			}
			if(e.getSource()==b4){
				login l=new login();
				login_view lv=new login_view();
				login_control lc=new login_control(l,lv);
				dispose();
				lv.setVisible(true);
			}
			if(e.getSource()==b3){
	            doctor_delete dv=new doctor_delete();
	            dv.setVisible(true);
	            
	          
			}
			
		}

		private void setDoctorId(String n) {
			// TODO Auto-generated method stub
			
		}
		
	}
	public String getDoctorId(){
		return f.getText();
	}
	public void setDoctorId(String i){
		f.setText(i);
	}
	public String getDoctorName(){
		return f1.getText();
	}
	public void setDoctorName(String i){
		f1.setText(i);
	}
	public String getDoctorAge(){
		return f2.getText();
	}
	public void setDoctorAge(String i){
		f2.setText(i);
	}
	public String getDoctorGender(){
		if(r[0].isSelected())
		return "male";
		else if(r[1].isSelected())
			return "female";
		else
			return " ";
	}
	public void setDoctorGender(String i){
		f3.setText(i);
	}
	public String getDoctorDOB(){
		return f4.getText();
	}
	public void setDoctorDOB(String i){
		f4.setText(i);
	}
	public String getDoctorDep(){
		return f5.getText();
	}
	public void setDoctorDep(String i){
		f5.setText(i);
	}
	public String getDoctorTiming(){
		return f6.getText();
	}
	public void setDoctorTiming(String i){
		f6.setText(i);
	}
	public String getDoctorSep(){
		return f7.getText();
	}
	public void setDoctorSep(String i){
		f7.setText(i);
	}
	public String getDoctorQualiiaction(){
		return f8.getText();
	}
	public void setDoctorQualiiaction(String i){
		f8.setText(i);
	}
	public String getDoctorType(){
		if(r[2].isSelected())
			return "indoor";
			else if(r[3].isSelected())
				return "outdoor";
			else
				return " ";
	}
	/*public void setDoctorType(String i){
		 f9.setText(i);
	}*/
	public String getDoctorNum(){
		return f10.getText();
	}
	public void setDoctorNum(String i){
	f10.setText(i);
	}
	public String getDoctorAddress(){
		return f11.getText();
	}
	public void setDoctorAddress(String i){
	 f11.setText(i);
	}
	public String getDoctorHireDate(){
		return f12.getText();
	}
	public void setDoctorHireDate(String i){
		f12.setText(i);
	}
	public String getDoctorStaffType(){
		return f13.getText();
	}
	public void setDoctorStaffType(String i){
		f13.setText(i);
	}
	public void AddDocSave(ActionListener e){
		b.addActionListener(e);
	}
	public void AddDocSearch(ActionListener e){
		b1.addActionListener(e);
	}
	public void AddDocEdit(ActionListener e){
		b2.addActionListener(e);
	}
	
	
	public ArrayList<doctor>  readAllData ()
    {
      //  ArrayList initialized with size 0
ArrayList<doctor> doctorList = new ArrayList<doctor>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("doctor.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
	// read object and type cast into CarDetails object
	doctor myObj = (doctor) inputStream.readObject();
	// add object into ArrayList
	doctorList.add(myObj);
	//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
	//System.out.println("Class not found");
} catch (EOFException end) {
	// EOFException is raised when file ends
	// set End Of File flag to true so that loop exits
	EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
	inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return doctorList;
}

}

