package view;

public class discharge_view {

}
