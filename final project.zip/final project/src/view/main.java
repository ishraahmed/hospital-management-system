package view;

public class main {
	public static void main(String args[]){
workers_info pi=new workers_info();
pi.setVisible(true);
}}
