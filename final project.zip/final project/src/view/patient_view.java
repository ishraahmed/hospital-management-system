package view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;

import control.login_control;
import model.login;

import java.io.*;

public class patient_view extends JFrame implements Serializable {
	JLabel l;
	JTextField f;
	JLabel l1;
	JTextField f1;
	JLabel l2;
	JTextField f2;
	JLabel l3;
	JTextField f3;
	JLabel l4;
	JTextField f4;
	JLabel l5;
	JTextField f5;
	JLabel l6;
	JTextField f6;
	JLabel l7;
	JTextField f7;
	JLabel[] lb=new JLabel[16];
	JLabel lp;
	JLabel lp1;
	JLabel lp2;
	JButton b;
	JButton b1;
	JButton b2;
	JButton[] bb=new JButton[4];
	JLabel ll=new JLabel();
	JRadioButton[] r=new JRadioButton[2];
	ButtonGroup g=new ButtonGroup();
	public patient_view(){
		super("Patient");
		setContentPane(new JLabel(new ImageIcon("image1.jpg")));
		r[0]=new JRadioButton("male",true);
		r[1]=new JRadioButton("female",true);
		g.add(r[0]);
		g.add(r[1]);
		JLabel pot=new JLabel("                                                Patient's Record");
		pot.setFont(new Font("ALGERIAN",Font.BOLD,35));
		bb[0]=new JButton("Home");
		bb[1]=new JButton("Back");
		bb[2]=new JButton("Logout");
		bb[3]=new JButton("Bill");
		ll=new JLabel("                                                                         ");
		l=new JLabel("                           Name");
		l.setFont(new Font("Serif",Font.BOLD,20));
		f=new JTextField(10);
		l1=new JLabel("                                 Age");
		l1.setFont(new Font("Serif",Font.BOLD,20));
		f1=new JTextField(10);
		l2=new JLabel("                          Gender");
		l2.setFont(new Font("Serif",Font.BOLD,20));
		f2=new JTextField(10);
		l3=new JLabel("                         Date of birth");
		l3.setFont(new Font("Serif",Font.BOLD,20));
		f3=new JTextField(10);
		l4=new JLabel("                          Patient's id");
		l4.setFont(new Font("Serif",Font.BOLD,20));
		f4=new JTextField(10);
		l5=new JLabel("                          Date of visit"); 
		l5.setFont(new Font("Serif",Font.BOLD,20));
		f5=new JTextField(10);
		l6=new JLabel("                          Consultant");
		l6.setFont(new Font("Serif",Font.BOLD,20));
		f6=new JTextField(10);
		l7=new JLabel("                           Consultantdep");
		l7.setFont(new Font("Serif",Font.BOLD,20));
		f7=new JTextField(10);
		b=new JButton("save");
		b1=new JButton("search");
		b2=new JButton("admit");
		this.setLayout(new BorderLayout());
		JPanel p=new JPanel();
		JPanel ppp=new JPanel();
		p.setOpaque(false);
		ppp.setOpaque(false);
		ppp.add(r[0]);
		ppp.add(r[1]);
		p.setLayout(new GridLayout(9,4));
		lp1=new JLabel();
		lp2=new JLabel();
		p.add(lp1);
		p.add(lp2);
		JLabel lp3=new JLabel();
		JLabel lp4=new JLabel();
		p.add(lp3);
		p.add(lp4);
		JLabel lp5=new JLabel();
		JLabel lp6=new JLabel();
		JLabel lp7=new JLabel();
		JLabel lp8=new JLabel();
		lb[0]=new JLabel();
		lb[1]=new JLabel();
		lb[2]=new JLabel();
		lb[3]=new JLabel();
		lb[4]=new JLabel();
		lb[5]=new JLabel();
		lb[6]=new JLabel();
		lb[7]=new JLabel();
		lb[8]=new JLabel();
		lb[9]=new JLabel();
		lb[10]=new JLabel();
		lb[11]=new JLabel();
		lb[12]=new JLabel();
		lb[13]=new JLabel();
		lb[14]=new JLabel("       ");
		lb[15]=new JLabel("                         ");
		JPanel p1=new JPanel();
		p1.setOpaque(false);
		p1.add(pot);
		p1.add(ll);
		p1.add(bb[0]);
		p1.add(bb[1]);
		p1.add(bb[2]);
		JPanel p2=new JPanel();
		p2.setOpaque(false);
		p2.add(b);
		p2.add(b1);
		p2.add(b2);
		p2.add(bb[3]);
		this.add(p2,BorderLayout.SOUTH);
		JPanel p3=new JPanel(new GridLayout(0,2));
		JPanel p4=new JPanel(new GridLayout(0,2));
		p3.setOpaque(false);
		p4.setOpaque(false);
		p3.add(lb[14]);
		p4.add(lb[15]);
		p.add(l4);
		p.add(f4);
		p.add(l);
		p.add(f);
		p.add(lb[0]);
		p.add(lb[1]);
		p.add(lb[2]);
		p.add(lb[3]);
		p.add(l3);
		p.add(f3);
		p.add(l1);
		p.add(f1);
		p.add(lb[4]);
		p.add(lb[5]);
		p.add(lb[6]);
		p.add(lb[7]);
		p.add(l2);
		p.add(ppp);
		p.add(l5);
		p.add(f5);
		p.add(lb[8]);
		p.add(lb[9]);
		p.add(lb[10]);
		p.add(lb[11]);
		p.add(l6);
		p.add(f6);
		p.add(l7);
		p.add(f7);
		p.add(lp5);
		p.add(lp6);
		p.add(lp7);
		p.add(lp8);
		this.add(p,BorderLayout.CENTER);
		this.add(p1,BorderLayout.NORTH);
		this.add(p3,BorderLayout.WEST);
		this.add(p4,BorderLayout.EAST);
		this.setSize(1350,720);
		MyButton butt=new MyButton();
		bb[0].addActionListener(butt);
		bb[1].addActionListener(butt);
		bb[2].addActionListener(butt);
		bb[3].addActionListener(butt);
	}
	class MyButton implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==bb[3]){
				bill_view bv=new bill_view();
				bv.setVisible(true);
			}
			if(e.getSource()==bb[0]){
				dispose();
				frame f=new frame();
				f.setVisible(true);
			}
			if(e.getSource()==bb[1]){
				dispose();
				frame f=new frame();
				f.setVisible(true);
			}
			if(e.getSource()==bb[2]){
				dispose();
				login l=new login();
				login_view lv=new login_view();
				login_control lc=new login_control(l,lv);
				lv.setVisible(true);
			}
			
		}
		
	}
	public String getId(){
		return f4.getText();
	}
	public String getAge(){
		return f1.getText();
	}
	public String getName(){
		return f.getText();
	}
	public String getGender(){
		if(r[0].isSelected())
			return "male";
		else if(r[1].isSelected())
			return "female";
		else
			return "";
	}
	public String getDOB(){
		return f3.getText();
	}
	
	public String getDOV(){
		return f5.getText();
	}
	public String getConsultant(){
		return f6.getText();
	}
	public String getConsultantDep(){
		return f7.getText();
	}
	public void setPatientId(String i){
		f4.setText(i);
	}
	public void setAge(String i){
		f1.setText(i);
	}
	public void setName(String i){
		f.setText(i);
	}
	public void setGender(String i){
		f2.setText(i);
	}
	public void setDOB(String i){
		f3.setText(i);
	}
	
	public void setDOV(String i){
		f5.setText(i);
	}
	public void setConsultant(String i){
		f6.setText(i);
	}
	public void setConsultantDep(String i){
		f7.setText(i);
	}
public	void addPatientSave(ActionListener e){
	b.addActionListener(e);}
	public void addSearchPatient(ActionListener e){
		b1.addActionListener(e);
	}
	public void addAdmitListener(ActionListener e){
		b2.addActionListener(e);
	}
}

