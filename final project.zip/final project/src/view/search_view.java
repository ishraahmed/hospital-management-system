package view;

import java.io.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.patient;
public class search_view extends JFrame implements Serializable {
	JLabel l;
	JLabel l1;
	JLabel l2;
	JLabel l3;
	JLabel l4;
	JLabel[] lb=new JLabel[15];
	JTextField f;
	JButton sub;
	public search_view(){
		super("Patient");
		setContentPane(new JLabel(new ImageIcon("image5.jpg")));
		this.setLayout(new BorderLayout());
		JPanel p=new JPanel(new GridLayout(5,2));
		JPanel p1=new JPanel(new GridLayout(8,0));
		JPanel p2=new JPanel(new BorderLayout());
		p.setOpaque(false);
		p1.setOpaque(false);
		p2.setOpaque(false);
		l=new JLabel("              Enter patient id");
		l.setFont(new Font("Serif",Font.BOLD,18));
		f=new JTextField(10);
		sub=new JButton("Search");
		l1=new JLabel(" ");
		l2=new JLabel(" ");
		JPanel p3=new JPanel();
		p3.setOpaque(false);
		l4=new JLabel("            Patient Search");
		l4.setFont(new Font("ALGERIAN",Font.BOLD,30));
		p3.add(l4);
		for(int i=0;i<15;i++){
			lb[i]=new JLabel("                                     ");
		}
		p.add(lb[0]);
		p.add(lb[1]);
		p.add(lb[7]);
		p.add(lb[8]);
		p.add(l);
		p.add(f);
		p.add(l1);
		p.add(l2);
		p.add(lb[2]);
		p.add(lb[3]);
		p1.add(p2);
		p1.add(lb[9]);
		p1.add(lb[10]);
		p1.add(lb[11]);
		p1.add(lb[12]);
		p1.add(lb[13]);
		p1.add(lb[14]);
		p2.add(sub,BorderLayout.CENTER);
		p2.add(lb[5],BorderLayout.EAST);
		p2.add(lb[6],BorderLayout.WEST);
		p1.add(lb[4]);
		this.add(p,BorderLayout.CENTER);
		this.add(p1,BorderLayout.SOUTH);
		this.add(l4,BorderLayout.NORTH);
		l3=new JLabel("                    ");
		this.add(l3,BorderLayout.EAST);
		this.setSize(500,500);
		this.setVisible(true);
		MyButton butt=new MyButton();
		sub.addActionListener(butt);
	}
	class MyButton implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			patient s=new patient();
			try {
				//JOptionPane.showMessageDialog(null,"record saved","information",JOptionPane.INFORMATION_MESSAGE);
				ObjectInputStream x = new ObjectInputStream(new FileInputStream("patient.ser"));
			while (true) {
				s = (patient) x.readObject();
					if (s.getPatientId().equals(f.getText())) {
						patient_info pi=new patient_info();
						pi.setName(s.getName());
						pi.setAge(s.getAge());
						pi.setGender(s.getGender());
						pi.setId(s.getPatientId());
						pi.setDOB(s.getDOB());
						pi.setDOV(s.getDOV());
						pi.setConsultant(s.getConsultant());
						pi.setConsultantDep(s.getConsultantdep());
						pi.setDOA(s.getDOA());
						pi.setWard(s.getRoom());
						pi.setRoom(s.getWard());
						pi.setBed(s.getBed());
						pi.setBill(s.getBill());
						pi.setDischargeDate(s.getDischargeDate());
						pi.setVisible(true);
						f.setText(null);
						break;
					}
				}
				//JOptionPane.showMessageDialog(null,"record saved","information",JOptionPane.INFORMATION_MESSAGE);
			}catch(Exception exp){
				return;
			}
			
		}
		
	}
}

