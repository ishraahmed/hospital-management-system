package view;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import control.login_control;
import model.login;
public class workersStaff_view extends JFrame{
JLabel[] l=new JLabel[13];
JLabel[] sp=new JLabel[28];
JLabel e;
JLabel w;
JTextField[] f=new JTextField[12];
JRadioButton[] rd=new JRadioButton[2];
ButtonGroup g=new ButtonGroup();
JButton[] b =new JButton[7];
workersStaff_view(){
	super("Workers Staff");
	setContentPane(new JLabel(new ImageIcon("image1.jpg")));
		l[0]=new JLabel("               Worker's Id");
		l[0].setFont(new Font("Serif",Font.BOLD,20));
		l[1]=new JLabel("                      Name");
		l[1].setFont(new Font("Serif",Font.BOLD,20));
		l[2]=new JLabel("               Date of Birth");
		l[2].setFont(new Font("Serif",Font.BOLD,20));
		l[3]=new JLabel("                      Age");
		l[3].setFont(new Font("Serif",Font.BOLD,20));
		l[12]=new JLabel("              Gender");
		l[12].setFont(new Font("Serif",Font.BOLD,20));
		rd[0]=new JRadioButton("male",true);
		rd[1]=new JRadioButton("female",false);
		g.add(rd[0]);
		g.add(rd[1]);
		JPanel panel=new JPanel();
		panel.add(rd[0]);
		panel.add(rd[1]);
		l[4]=new JLabel("                      Education");
		l[4].setFont(new Font("Serif",Font.BOLD,20));
		l[5]=new JLabel("              Phone NO");
		l[5].setFont(new Font("Serif",Font.BOLD,20));
		l[6]=new JLabel("                      Address");
		l[6].setFont(new Font("Serif",Font.BOLD,20));
		l[7]=new JLabel("              Hire Date");
		l[7].setFont(new Font("Serif",Font.BOLD,20));
		l[8]=new JLabel("                      Salary");
		l[8].setFont(new Font("Serif",Font.BOLD,20));
		l[9]=new JLabel("              Staff Type");
		l[9].setFont(new Font("Serif",Font.BOLD,20));
		l[10]=new JLabel("                                       Worker's Staff View");
		l[10].setFont(new Font("ALGERIAN",Font.BOLD,35));
		l[11]=new JLabel("                                                                   ");
		for(int i=0;i<10;i++){
			f[i]=new JTextField(10);
		}
		for(int i=0;i<28;i++){
			sp[i]=new JLabel("      ");
		}
		this.setLayout(new BorderLayout());
		b[0]=new JButton("Logout");
		b[1]=new JButton("Home");
		b[2]=new JButton("Back");
		b[3]=new JButton("Save");
		b[4]=new JButton("Search");
		b[5]=new JButton("Edit");
		b[6]=new JButton("Delete");
		JPanel p=new JPanel(new GridLayout(13,4));
		JPanel p1=new JPanel();
		p.setOpaque(false);
		p1.setOpaque(false);
		p1.add(l[10]);
		p1.add(l[11]);
		p1.add(b[0]);
		p1.add(b[1]);
		p1.add(b[2]);
		p.add(sp[24]);
		p.add(sp[25]);
		p.add(sp[26]);
		p.add(sp[27]);
		p.add(l[0]);
		p.add(f[0]);
		p.add(l[1]);
		p.add(f[1]);
		p.add(sp[0]);
		p.add(sp[1]);
		p.add(sp[2]);
		p.add(sp[3]);
		p.add(l[2]);
		p.add(f[2]);
		p.add(l[3]);
		p.add(f[3]);
		p.add(sp[4]);
		p.add(sp[5]);
		p.add(sp[6]);
		p.add(sp[7]);
		p.add(l[12]);
		p.add(panel);
		p.add(l[4]);
		p.add(f[4]);
		p.add(sp[8]);
		p.add(sp[9]);
		p.add(sp[10]);
		p.add(sp[11]);
		p.add(l[5]);
		p.add(f[5]);
		p.add(l[6]);
		p.add(f[6]);
		p.add(sp[12]);
		p.add(sp[13]);
		p.add(sp[14]);
		p.add(sp[15]);
		p.add(l[7]);
		p.add(f[7]);
		p.add(l[8]);
		p.add(f[8]);
		p.add(sp[16]);
		p.add(sp[17]);
		p.add(sp[18]);
		p.add(sp[19]);
		p.add(l[9]);
		p.add(f[9]);
		p.add(sp[20]);
		p.add(sp[21]);
		p.add(sp[22]);
		p.add(sp[23]);
		JPanel p2=new JPanel();
		p2.setOpaque(false);
		p2.add(b[3]);
		p2.add(b[4]);
		p2.add(b[5]);
		p2.add(b[6]);
		e=new JLabel("                         ");
		w=new JLabel("         ");
		this.setSize(1350,720);
		this.add(p,BorderLayout.CENTER);
		this.add(p1,BorderLayout.NORTH);
		this.add(p2,BorderLayout.SOUTH);
		this.add(e,BorderLayout.EAST);
		this.add(w,BorderLayout.WEST);
		validate();
		MyButton butt=new MyButton();
		b[0].addActionListener(butt);
		b[1].addActionListener(butt);
		b[2].addActionListener(butt);
}
class MyButton implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b[0]){
			dispose();
			login l=new login();
			login_view lv=new login_view();
			login_control lc=new login_control(l,lv);
			lv.setVisible(true);
		}
		if(e.getSource()==b[1]){
			dispose();
		frame f=new frame();
		f.setVisible(true);
				}
		if(e.getSource()==b[2]){
			dispose();
		frame f=new frame();
		f.setVisible(true);
				}
		
	}
	
}
public String getWorkerId(){
	return f[0].getText();
}
public void setWorkerId(String i){
	f[0].setText(i);
}
public String getWorkerName(){
	return f[1].getText();
}
public void setWorkerName(String i){
	f[1].setText(i);
}
public String getWorkerDOB(){
	return f[2].getText();
}
public void setWorkerDOB(String i){
	f[2].setText(i);
}
public String getWorkerAge(){
	return f[3].getText();
}
public void setWorkerAge(String i){
	f[3].setText(i);
}
public String getWorkerGender(){
	if(rd[0].isSelected())
		return "male";
	if(rd[1].isSelected())
		return "female";
	else return " ";
}
public String getWorkerEducation(){
	return f[4].getText();
}
public void setWorkerEducation(String i){
	f[4].setText(i);
}
public String getWorkerNum(){
	return f[5].getText();
}
public void setWorkerNum(String i){
	f[5].setText(i);
}
public String getWorkerAddress(){
	return f[6].getText();
}
public void setWorkerAddress(String i){
	f[6].setText(i);
}
public String getWorkerHireDate(){
	return f[7].getText();
}
public void setWorkerHireDate(String i){
	f[7].setText(i);
}
public String getWorkerSalary(){
	return f[8].getText();
}
public void setWorkerSalary(String i){
	f[8].setText(i);
}
public String getWorkerStaffType(){
	return f[9].getText();
}
public void setWorkerStaffType(String i){
	f[9].setText(i);
}
public void addSaveWorker(ActionListener e){
	b[3].addActionListener(e);
}
public void addSearchWorker(ActionListener e){
	b[4].addActionListener(e);
}
public void addEditWorker(ActionListener e){
	b[5].addActionListener(e);
}
public void addDeleteWorker(ActionListener e){
	b[6].addActionListener(e);
}
}
