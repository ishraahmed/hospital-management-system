package view;
import java.awt.BorderLayout;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class workers_info extends JFrame{
JLabel main;
JLabel sp;
JLabel[] l=new JLabel[13];
JLabel[] lp=new JLabel[30];
JTextField[] f=new JTextField[13];
JButton b;
workers_info(){
	super("workers Staff");
	setContentPane(new JLabel(new ImageIcon("image1.jpg")));
	this.setLayout(new BorderLayout());
	l[0]=new JLabel("            Worker's Id");
	l[0].setFont(new Font("Serif",Font.BOLD,20));
	l[1]=new JLabel("                       Name");
	l[1].setFont(new Font("Serif",Font.BOLD,20));
	l[2]=new JLabel("            Date of Birth");
	l[2].setFont(new Font("Serif",Font.BOLD,20));
	l[3]=new JLabel("                       Age");
	l[3].setFont(new Font("Serif",Font.BOLD,20));
	l[4]=new JLabel("            Gender");
	l[4].setFont(new Font("Serif",Font.BOLD,20));
	l[5]=new JLabel("                       Education");
	l[5].setFont(new Font("Serif",Font.BOLD,20));
	l[6]=new JLabel("            Hire Date");
	l[6].setFont(new Font("Serif",Font.BOLD,20));
	l[7]=new JLabel("                       Phone Number");
	l[7].setFont(new Font("Serif",Font.BOLD,20));
	l[8]=new JLabel("            Address");
	l[8].setFont(new Font("Serif",Font.BOLD,20));
	l[9]=new JLabel("                       Salary");
	l[9].setFont(new Font("Serif",Font.BOLD,20));
	l[12]=new JLabel("           Staff Type");
	l[12].setFont(new Font("Serif",Font.BOLD,20));
	for(int i=0;i<13;i++){
	f[i]=new JTextField();	
	}
	JPanel p=new JPanel(new GridLayout(13,4));
	p.setOpaque(false);
	for(int i=0;i<30;i++){
		lp[i]=new JLabel("  ");
	}
	p.add(lp[0]);
	p.add(lp[1]);
	p.add(lp[2]);
	p.add(lp[3]);
	p.add(l[0]);
	p.add(f[0]);
	p.add(l[1]);
	p.add(f[1]);
	p.add(lp[4]);
	p.add(lp[5]);
	p.add(lp[6]);
	p.add(lp[7]);
	p.add(l[2]);
	p.add(f[2]);
	p.add(l[3]);
	p.add(f[3]);
	p.add(lp[8]);
	p.add(lp[9]);
	p.add(lp[10]);
	p.add(lp[11]);
	p.add(l[4]);
	p.add(f[4]);
	p.add(l[5]);
	p.add(f[5]);
	p.add(lp[12]);
	p.add(lp[13]);
	p.add(lp[14]);
	p.add(lp[15]);
	p.add(l[6]);
	p.add(f[6]);
	p.add(l[7]);
	p.add(f[7]);
	p.add(lp[16]);
	p.add(lp[17]);
	p.add(lp[18]);
	p.add(lp[19]);
	p.add(l[8]);
	p.add(f[8]);
	p.add(l[9]);
	p.add(f[9]);
	p.add(lp[20]);
	p.add(lp[21]);
	p.add(lp[22]);
	p.add(lp[23]);
	p.add(l[12]);
	p.add(f[12]);
	p.add(lp[24]);
	p.add(lp[25]);
	p.add(lp[26]);
	p.add(lp[27]);
	JPanel p1=new JPanel();
	p1.setOpaque(false);
	sp=new JLabel("                                                                                                                           ");
	b=new JButton("Back");
	main=new JLabel("                                    Workers Information");
	main.setFont(new Font("ALGERIAN",Font.BOLD,35));
	p1.add(main);
	p1.add(sp);
	p1.add(b);
	lp[24]=new JLabel("                                  ");
	lp[25]=new JLabel("             ");
   this.add(p,BorderLayout.CENTER);
   this.add(p1,BorderLayout.NORTH);
   this.add(lp[24],BorderLayout.EAST);
   this.add(lp[25],BorderLayout.WEST);
   this.setSize(1350,720);
   MyButton butt=new MyButton();
   b.addActionListener(butt);
}
public void setWorkerId(String i){
	f[0].setText(i);
}
public void setWorkerName(String i){
	f[1].setText(i);
}
public void setWorkerDOB(String i){
	f[2].setText(i);
}
public void setWorkerAge(String i){
	f[3].setText(i);
}
public void setWorkerGender(String i){
	f[4].setText(i);
}
public void setWorkerEducation(String i){
	f[5].setText(i);
}
public void setWorkerHireDate(String i){
	f[6].setText(i);
}
public void setWorkerNumber(String i){
	f[7].setText(i);
}
public void setWorkerAddress(String i){
	f[8].setText(i);
}
public void setWorkerSalary(String i){
	f[9].setText(i);
}
public void setWorkerStaffType(String i){
	f[12].setText(i);
}
class MyButton implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b)
		dispose();
	}
	
	
} 
}
