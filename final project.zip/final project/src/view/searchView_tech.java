package view;

import java.io.*;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import model.administrator;
import model.patient;
import model.technicalStaff;
public class searchView_tech extends JFrame {
	JLabel l;
	JLabel l1;
	JLabel l2;
	JLabel l3;
	JLabel l4;
	JLabel[] lb=new JLabel[15];
	JTextField f;
	JButton sub;
	public searchView_tech(){
		super("Technical Staff");
		setContentPane(new JLabel(new ImageIcon("image5.jpg")));
		l4=new JLabel("          Technician Search");
		l4.setFont(new Font("ALGERIAN",Font.BOLD,30));
		this.setLayout(new BorderLayout());
		JPanel p=new JPanel(new GridLayout(5,2));
		p.setOpaque(false);
		JPanel p1=new JPanel(new GridLayout(8,0));
		p1.setOpaque(false);
		JPanel p2=new JPanel(new BorderLayout());
		p2.setOpaque(false);
		l=new JLabel("              Enter Technician Id");
		l.setFont(new Font("serif",Font.BOLD,15));
		f=new JTextField(10);
		sub=new JButton("Search");
		l1=new JLabel(" ");
		l2=new JLabel(" ");
		for(int i=0;i<15;i++){
			lb[i]=new JLabel("                                     ");
		}
		p.add(lb[0]);
		p.add(lb[1]);
		p.add(lb[7]);
		p.add(lb[8]);
		p.add(l);
		p.add(f);
		p.add(l1);
		p.add(l2);
		p.add(lb[2]);
		p.add(lb[3]);
		p1.add(p2);
		p1.add(lb[9]);
		p1.add(lb[10]);
		p1.add(lb[11]);
		p1.add(lb[12]);
		p1.add(lb[13]);
		p1.add(lb[14]);
		p2.add(sub,BorderLayout.CENTER);
		p2.add(lb[5],BorderLayout.EAST);
		p2.add(lb[6],BorderLayout.WEST);
		p1.add(lb[4]);
		this.add(p,BorderLayout.CENTER);
		this.add(p1,BorderLayout.SOUTH);
		l3=new JLabel("                    ");
		this.add(l3,BorderLayout.EAST);
		this.add(l4,BorderLayout.NORTH);
		this.setSize(500,500);
		this.setVisible(true);
		MyButton3 butt=new MyButton3();
		sub.addActionListener(butt);
	}
	class MyButton3 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==sub){
				ObjectInputStream inputStream=null;
				technicalStaff ad;
				try{
					inputStream=new ObjectInputStream(new FileInputStream("tech.ser"));
					while(true){
						ad=(technicalStaff)inputStream.readObject();
						if(ad.getId().equals(f.getText())){
							tech_info ti=new tech_info();
							ti.setTechId(ad.getId());
							ti.setTechName(ad.getName());
							ti.setTechDOB(ad.getDOB());
							ti.setTechAge(ad.getAge());
							ti.setTechGender(ad.getGender());
							ti.setTechHireDate(ad.getHireDate());
							ti.setTechNumber(ad.getNum());
							ti.setTechSalary(ad.getStaffType());
							ti.setTechAddress(ad.getAddress());
							ti.setTechEducation(ad.getEducation());
							ti.setVisible(true);
							f.setText(null);
						}
					}
				}
				catch(Exception exp){
					return;
				}
				
			}
		}}
	public ArrayList<technicalStaff>  readAllData ()
	{
	  //  ArrayList initialized with size 0
	ArrayList<technicalStaff> techList = new ArrayList<technicalStaff>(0);
	// Input stream
	ObjectInputStream inputStream = null;
	try
	{
	// open file for reading
	inputStream = new ObjectInputStream(new FileInputStream("tech.ser"));
	// End Of File flag
	boolean EOF = false;
	// Keep reading file until file ends
	while(!EOF) {
	try {
	// read object and type cast into CarDetails object
		technicalStaff myObj = (technicalStaff) inputStream.readObject();
	// add object into ArrayList
	techList.add(myObj);
	//System.out.println("Read: " + myObj.getName());
	} catch (ClassNotFoundException e) {
	//System.out.println("Class not found");
	} catch (EOFException end) {
	// EOFException is raised when file ends
	// set End Of File flag to true so that loop exits
	EOF = true;
	}
	}
	} catch(FileNotFoundException e) {
	//System.out.println("Cannot find file");
	} catch (IOException e) {
	//System.out.println("IO Exception while opening stream");
	//e.printStackTrace();
	} finally { // cleanup code to close stream if it was opened
	try {
	if(inputStream != null)
	inputStream.close( );
	} catch (IOException e) {
	// TODO Auto-generated catch block
	System.out.println("IO Exception while closing file");
	}
	}
	// returns ArrayList
	return techList;
	}	
}