package view;
import java.io.*;
import java.util.ArrayList;
import model.newUser;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class newUser_view extends JFrame{
	JLabel l;
	JTextField f;
	JLabel l1;
	JTextField f1;
	JLabel l2;
	JTextField f2;
	JLabel l3;
	JTextField f3;
	JLabel l5;
	JLabel l6;
	JLabel[] ll=new JLabel[8];
	JLabel[] pl=new JLabel[2];
	JButton save;
	JButton back;
	public newUser_view(){
		this.setLayout(new BorderLayout());
		l=new JLabel("Username");
		l.setFont(new Font("Serif",Font.BOLD,20));
		f=new JTextField(10);
		l1=new JLabel("Password");
		l1.setFont(new Font("Serif",Font.BOLD,20));
		f1=new JTextField(10);
		l2=new JLabel("What is your mother's birth place?");
		l2.setFont(new Font("Serif",Font.BOLD,20));
		f2=new JTextField(10);
		l3=new JLabel("What is your best friend's name?");
		l3.setFont(new Font("Serif",Font.BOLD,20));
		f3=new JTextField(10);
		l5=new JLabel("                                                 New User");
		l6=new JLabel("                                                                                                                                                  ");
		l5.setFont(new Font("ALGERIAN",Font.BOLD,35));
		save=new JButton("Save");
		back=new JButton("Back");
		JPanel p=new JPanel(new GridLayout(15,0));
		JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		JPanel p4=new JPanel(new BorderLayout());
		JPanel p5=new JPanel();
		JPanel p6=new JPanel();
		for(int i=0;i<2;i++){
			pl[i]=new JLabel("                                                 ");
		}
		p5.add(pl[0]);
		p6.add(pl[1]);
		p4.add(save,BorderLayout.CENTER);
		p4.add(p5,BorderLayout.EAST);
		p4.add(p6,BorderLayout.WEST);
		p1.add(l5);
		p1.add(l6);
		p1.add(back);
		for(int i=0;i<8;i++){
			ll[i]=new JLabel("                                                                                                                                                ");
		}
		p2.add(ll[6]);
		p3.add(ll[7]);
		p.add(ll[0]);
		p.add(l);
		p.add(f);
		p.add(ll[1]);
		p.add(l1);
		p.add(f1);
		p.add(ll[2]);
		p.add(l2);
		p.add(f2);
		p.add(ll[3]);
		p.add(l3);
		p.add(f3);
		p.add(ll[4]);
		p.add(p4);
		p.add(ll[5]);
		this.add(p1,BorderLayout.NORTH);
		this.add(p,BorderLayout.CENTER);
		this.add(p2,BorderLayout.EAST);
		this.add(p3,BorderLayout.WEST);
		this.setSize(1350,720);
		Save s=new Save();
		save.addActionListener(s);
	}
public	void addBackListener(ActionListener a){
		back.addActionListener(a);
	}
	class Save implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			newUser us=new newUser();
			String u,p,q1,q2;
			u=f.getText();
			p=f1.getText();
			q1=f2.getText();
			q2=f3.getText();
			us=new newUser(u,p,q1,q2);
	ObjectOutputStream outputStream = null;
			
			try {
				ArrayList<newUser> UserList = readAllData();
				UserList.add(us);
				outputStream = new ObjectOutputStream(new FileOutputStream("List.ser"));
				for(int i = 0 ; i < UserList.size() ; i++) {
					outputStream.writeObject(UserList.get(i));
				}
				JOptionPane.showMessageDialog(null,"record saved","information",JOptionPane.INFORMATION_MESSAGE);
			} catch(IOException exp) {
				System.out.println("IO Exception while opening file");
			} finally { // cleanup code which closes output stream if its object was created
				try {
					if(outputStream != null) {
						outputStream.close();
						// flag of success
						
					}

				} catch (IOException exp) {
					System.out.println("IO Exception while closing file");
				}
			}
			
			}
		}

	public ArrayList<newUser>  readAllData ()
	{
	  //  ArrayList initialized with size 0
	ArrayList<newUser> UserList = new ArrayList<newUser>(0);
	// Input stream
	ObjectInputStream inputStream = null;
	try
	{
	// open file for reading
	inputStream = new ObjectInputStream(new FileInputStream("List.ser"));
	// End Of File flag
	boolean EOF = false;
	// Keep reading file until file ends
	while(!EOF) {
	try {
	// read object and type cast into CarDetails object
	newUser myObj = (newUser) inputStream.readObject();
	// add object into ArrayList
	UserList.add(myObj);
	//System.out.println("Read: " + myObj.getName());
	} catch (ClassNotFoundException e) {
	//System.out.println("Class not found");
	} catch (EOFException end) {
	// EOFException is raised when file ends
	// set End Of File flag to true so that loop exits
	EOF = true;
	}
	}
	} catch(FileNotFoundException e) {
	//System.out.println("Cannot find file");
	} catch (IOException e) {
	//System.out.println("IO Exception while opening stream");
	//e.printStackTrace();
	} finally { // cleanup code to close stream if it was opened
	try {
	if(inputStream != null)
	inputStream.close( );
	} catch (IOException e) {
	// TODO Auto-generated catch block
	System.out.println("IO Exception while closing file");
	}
	}
	// returns ArrayList
	return UserList;
	}
	
}
