package view;
import javax.swing.*;

import model.doctor;
import model.newUser;
import model.patient;

import java.awt.*;
import java.awt.event.*;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
public class admit_view extends JFrame{
JLabel l;
JLabel l1;
JLabel l2;
JLabel l3;
JLabel l4;
JLabel l6;
JLabel l5;
JLabel l7;
JLabel l8;
JLabel[] lb=new JLabel[23];
JTextField f;
JTextField f1;
JTextField f2;
JTextField f3;
JTextField f4;
JButton b;
JButton b1;
public String name,age,gender,dob,patId,dov,consultant,consultantdep,doa,room,ward,bed,bill,dis;
public admit_view(){
	super("Patient");
	setContentPane(new JLabel(new ImageIcon("image1.jpg")));
	this.setLayout(new BorderLayout());
	JPanel p=new JPanel(new GridLayout(11,2));
	JPanel p1=new JPanel();
	JPanel p2=new JPanel(new GridLayout(2,5));
	p.setOpaque(false);
	p1.setOpaque(false);
	p2.setOpaque(false);
	l=new JLabel("Date of admitance");
	l.setFont(new Font("Serif",Font.BOLD,25));
	l1=new JLabel("Ward");
	l1.setFont(new Font("Serif",Font.BOLD,25));
	l2=new JLabel("Room no");
	l2.setFont(new Font("Serif",Font.BOLD,25));
	l3=new JLabel("Bed no");
	l3.setFont(new Font("Serif",Font.BOLD,25));
	l6=new JLabel("Patient Id");
	l6.setFont(new Font("Serif",Font.BOLD,25));
	l4=new JLabel("                                            Admit View");
	l4.setFont(new Font("ALGERIAN",Font.BOLD,35));
	l5=new JLabel("                                                                                                                                                              ");
	l7=new JLabel("  ");
	l8=new JLabel("  ");
	b1=new JButton("Back");
	p1.add(l4);
	p1.add(l5);
	p1.add(b1);
	for(int i=0;i<12;i++){
		lb[i]=new JLabel("                                                                                                         ");
	}
	f=new JTextField(10);
	f=new JTextField(10);
	f1=new JTextField(10);
	f2=new JTextField(10);
	f3=new JTextField(10);
	f4=new JTextField(10);
	b=new JButton("Submit");
	p.add(l7);
	p.add(l8);
	p.add(l6);
	p.add(f4);
	p.add(lb[2]);
	p.add(lb[3]);
	p.add(l);
	p.add(f);
	p.add(lb[4]);
	p.add(lb[5]);
	p.add(l1);
	p.add(f1);
	p.add(lb[6]);
	p.add(lb[7]);
	p.add(l2);
	p.add(f2);
	p.add(lb[8]);
	p.add(lb[9]);
	p.add(l3);
	p.add(f3);
	p.add(lb[10]);
	p.add(lb[11]);
	//lb[12]=new JLabel("  ");
	for(int i=12;i<23;i++){
		lb[i]=new JLabel("   ");
	}
	p2.add(lb[12]);
	p2.add(lb[16]);
	p2.add(lb[21]);
	p2.add(b);
	p2.add(lb[17]);
	p2.add(lb[18]);
	p2.add(lb[19]);
	p2.add(lb[13]);
	p2.add(lb[14]);
	p2.add(lb[15]);
	p2.add(lb[22]);
	this.add(p,BorderLayout.CENTER);
	this.add(p1,BorderLayout.NORTH);
	this.add(p2,BorderLayout.SOUTH);
	this.add(lb[0],BorderLayout.EAST);
	this.add(lb[1],BorderLayout.WEST);
	this.setSize(1350,720);
	this.setVisible(true);
	MyButton butt=new MyButton();
		b.addActionListener(butt);
		b1.addActionListener(butt);
}
class MyButton implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		//patient(String name, String age, String gender, String dOB,String patientID1,
		//String dov1,doctor doc,String a,String b,String c,String d)
		if(e.getSource()==b1)
			dispose();
		if(e.getSource()==b){
			 
            ArrayList<patient> patientList = readAllData() ;
            File file = new File("patient.ser");
            
            for(int i = 0 ; i<patientList.size() ; i++){
            	if(patientList.get(i).getPatientId().equalsIgnoreCase(f4.getText()))
            	{
                    name=patientList.get(i).getName();
                    age=patientList.get(i).getAge();
                    gender=patientList.get(i).getGender();
                    dob=patientList.get(i).getDOB();
                    patId=patientList.get(i).getPatientId();
                    dov=patientList.get(i).getDOV();
                    consultant=patientList.get(i).getConsultant();
                    consultantdep=patientList.get(i).getConsultantdep();
                    bill=patientList.get(i).getBill();
                    dis=patientList.get(i).getDischargeDate();
            		patientList.remove(i);
            	}
            
            }
            doctor d=new doctor(consultant,null,null,null,null,null,null,null,null,null,null,consultantdep,null,null);
            doa=f.getText();
            ward=f1.getText();
            room=f2.getText();
            bed=f3.getText();
            patient pat=new patient(name,age,gender,dob,patId,dov,d,doa,room,ward,bed,bill,dis);
            try {
		patientList.add(pat);
				ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
				for(int i = 0 ; i<patientList.size() ; i++){
					out.writeObject(patientList.get(i));
				}
				JOptionPane.showMessageDialog(new JFrame(),"Admit Record Saved Successfully!");
				f.setText(null);
				f1.setText(null);
				f2.setText(null);
				f3.setText(null);
				f4.setText(null);
	            }
				
             catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		}
	}}
public ArrayList<patient>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<patient> patientList = new ArrayList<patient>(0);
// Input stream
ObjectInputStream inputStream = null;
try
{
// open file for reading
inputStream = new ObjectInputStream(new FileInputStream("patient.ser"));
// End Of File flag
boolean EOF = false;
// Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
patient myObj = (patient) inputStream.readObject();
// add object into ArrayList
patientList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
// TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
// returns ArrayList
return patientList;
}
}

