package view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.*;
public class login_view extends JFrame implements Serializable {
	JLabel l;
	JTextField f=new JTextField(10);
	JLabel l1;
	JTextField f1=new JTextField(10);
	JButton login=new JButton("login");
	JButton b=new JButton("New User");
	JButton b1=new JButton("forgot password");
JLabel ll;
	public login_view(){
		super("hospital mangement system");
		setContentPane(new JLabel(new ImageIcon("image1.jpg")));

		l=new JLabel("username");
		l.setFont(new Font("ALGERIAN", Font.BOLD,30));
		l1=new JLabel("password");
		l1.setFont(new Font("ALGERIAN", Font.BOLD,30));
		ll=new JLabel("WELCOME TO HOSPITAL MANAGEMENT SYSTEM");
		ll.setFont(new Font("ALGERIAN", Font.BOLD,35));
		JPanel p=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		JPanel p4=new JPanel();
		JPanel p5=new JPanel();
		p.setOpaque(false);
		p2.setOpaque(false);
		p3.setOpaque(false);
		p4.setOpaque(false);
		p5.setOpaque(false);
		JLabel l7=new JLabel(" ");
		p5.add(l7);
		JPanel p6=new JPanel();
		p6.setOpaque(false);
		JLabel l6=new JLabel(" ");
		p5.add(l6);
		JPanel p10=new JPanel();
		p10.setOpaque(false);
		JLabel l10=new JLabel(" ");
		p5.add(l10);
		JLabel l11=new JLabel(" ");
		p5.add(l11);
		JLabel l12=new JLabel(" ");
		p5.add(l12);
		JPanel p13=new JPanel();
		p13.setOpaque(false);
		JLabel l13=new JLabel(" ");
		p5.add(l13);
		JPanel p14=new JPanel();
		p14.setOpaque(false);
		JLabel l14=new JLabel(" ");
		p5.add(l14);
		JPanel p15=new JPanel();
		p15.setOpaque(false);
		JLabel l15=new JLabel(" ");
		p5.add(l15);
		JPanel p16=new JPanel();
		p16.setOpaque(false);
		JLabel l16=new JLabel(" ");
		p5.add(l16);
		JPanel p17=new JPanel();
		p17.setOpaque(false);
		JLabel l17=new JLabel(" ");
		p5.add(l17);
		JPanel p18=new JPanel();
		p18.setOpaque(false);
		JLabel l18=new JLabel(" ");
		p5.add(l18);
		JPanel p19=new JPanel();
		p19.setOpaque(false);
		JLabel l19=new JLabel(" ");
		p5.add(l19);
		JPanel p20=new JPanel();
		p20.setOpaque(false);
		JLabel l20=new JLabel(" ");
		p5.add(l20);
		JLabel l9=new JLabel("                                                                                                                                         ");
		JLabel l8=new JLabel("                                                                                                                                           ");
		this.setLayout(new BorderLayout());
		p.setLayout(new GridLayout(10,2));
		JPanel p1=new JPanel();
		p1.setOpaque(false);
		JPanel pp=new JPanel();
		pp.setOpaque(false);
		p1.add(b);
		p1.add(b1);
		pp.add(login);
		p.add(p6);
		p.add(p5);
		p.add(p14);
		p.add(p13);
		p.add(p17);
		p.add(p18);
		p.add(l);
		p2.add(l9);
		p4.add(l8);
		p.add(f);
		p.add(l11);
		p.add(l12);
		p.add(l1);
		p.add(f1);
		p.add(p10);
		p.add(p15);
		p.add(p1);
		p.add(pp);
		p.add(p16);
		p.add(p19);
		p.add(p20);
		p3.add(ll);
		this.add(p);
		this.add(p,BorderLayout.CENTER);
		this.add(p2,BorderLayout.EAST);
		this.add(p3,BorderLayout.NORTH);
		this.add(p4,BorderLayout.WEST);
		this.setSize(1350,720);
		this.setVisible(true);
		validate();
	}
	public String getUsername(){
		return f.getText();
	}
	public String getPassword(){
		return f1.getText();
	}
	public void addNewUserListener(ActionListener e){
		b.addActionListener(e);
	}
	
public void addForgotPassword(ActionListener a){
	b1.addActionListener(a);
}
public void addLoginListener(ActionListener a){
	login.addActionListener(a);
}

}
