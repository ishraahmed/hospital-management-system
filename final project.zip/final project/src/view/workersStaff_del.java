package view;
import java.awt.BorderLayout;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.*;

import model.administrator;
import model.doctor;
import model.technicalStaff;
import model.workers_staff;
public class workersStaff_del extends JFrame {
JLabel l;
JTextField f;
JButton b;
JLabel l1;
JLabel[] lp=new JLabel[7];
public workersStaff_del(){
	super("Workers Staff");
	setContentPane(new JLabel(new ImageIcon("image5.jpg")));
	l=new JLabel("Enter Worker's Id:");
	l.setFont(new Font("Serif",Font.BOLD,20));
	l1=new JLabel("Delete Worker");
	l1.setFont(new Font("ALGERIAN",Font.BOLD,35));
	f=new JTextField(10);
	b=new JButton("Delete");
	for(int i=0;i<3;i++){
		lp[i]=new JLabel("  ");
	}
	lp[5]=new JLabel("    ");
	lp[6]=new JLabel("    ");
	JPanel p=new JPanel(new GridLayout(8,1));
	p.setOpaque(false);
	JPanel p1=new JPanel();
	p1.setOpaque(false);
	p1.add(l1);
	p.add(lp[5]);
	p.add(l);
	p.add(f);
	p.add(lp[0]);
	p.add(b);
	p.add(lp[1]);
	p.add(lp[2]);
	p.add(lp[6]);
	lp[3]=new JLabel("                                     ");
	lp[4]=new JLabel("                                     ");
	this.setLayout(new BorderLayout());
	this.add(p,BorderLayout.CENTER);
	this.add(p1,BorderLayout.NORTH);
	this.add(lp[3],BorderLayout.EAST);
	this.add(lp[4],BorderLayout.WEST);
	this.setSize(500, 500);
	MyButton butt=new MyButton();
	b.addActionListener(butt);
}
class MyButton implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b){
			  ArrayList<workers_staff> workerList = readAllData() ;
	            File file = new File("worker.ser");
	            String id =f.getText();
	            
	            for(int i = 0 ; i<workerList.size() ; i++){
	            	if(workerList.get(i).getId().equalsIgnoreCase(id))
	            	{
	            		workerList.remove(i);
	            		JOptionPane.showMessageDialog(new JFrame(),"Succesfully Deleted!");
	            	}
	            f.setText(null);
	                    }
	            try {
					ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
					for(int i = 0 ; i<workerList.size() ; i++){
						out.writeObject(workerList.get(i));
					}
		            }
					
	             catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

		}
	}
	
}
public ArrayList<workers_staff> readAllData(){
	ArrayList<workers_staff> workerList=new ArrayList<workers_staff>(0);
	ObjectInputStream inputStream=null;
	try{
		inputStream=new ObjectInputStream(new FileInputStream("worker.ser"));
		Boolean EOF=false;
		while(!EOF){
			try{
				workers_staff obj=(workers_staff)inputStream.readObject();
				workerList.add(obj);
				
			}
			catch (ClassNotFoundException e) {
				//System.out.println("Class not found");
				} catch (EOFException end) {
				// EOFException is raised when file ends
				// set End Of File flag to true so that loop exits
				EOF = true;
				}
		}
	}
	catch(FileNotFoundException e) {
		//System.out.println("Cannot find file");
		} catch (IOException e) {
		//System.out.println("IO Exception while opening stream");
		//e.printStackTrace();
		}finally { // cleanup code to close stream if it was opened
			try {
				if(inputStream != null)
				inputStream.close( );
				} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("IO Exception while closing file");
				}
				}
	return workerList;
}
}
