package view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.doctor;
import model.patient;

public class searchView_doc extends JFrame {
JLabel[] l=new JLabel[4];
JTextField[] f=new JTextField[4];
JButton b1;
JLabel l1;
JButton[] b=new JButton[4];
JLabel[] lb=new JLabel [20];
public searchView_doc(){
	super("Doctor");
	setContentPane(new JLabel(new ImageIcon("image1.jpg")));
	b1=new JButton("Back");
	this.setLayout(new BorderLayout());
	JPanel panel=new JPanel();
	panel.setOpaque(false);
	lb[0]=new JLabel("                                    Doctor's Serach View");
	lb[0].setFont(new Font("ALGERIAN",Font.BOLD,35));
	l1=new JLabel("                                                                                                                          ");
	panel.add(lb[0]);
	panel.add(l1);
	panel .add(b1);
	for(int i=1;i<19;i++){
		lb[i]=new JLabel("  ");
	}
	
	JPanel p=new JPanel(new GridLayout(17,0));
	p.setOpaque(false);
	JPanel p1=new JPanel(new GridLayout(1,2));
	p1.setOpaque(false);
	JPanel p2=new JPanel(new GridLayout(1,2));
	p2.setOpaque(false);
	JPanel p3=new JPanel(new GridLayout(1,2));
	p3.setOpaque(false);
	JPanel p4=new JPanel(new GridLayout(1,2));
	p4.setOpaque(false);
	JPanel p5=new JPanel();
	p5.setOpaque(false);
	JPanel p6=new JPanel();
	p6.setOpaque(false);
	JPanel p7=new JPanel(new GridLayout(1,3));
	p7.setOpaque(false);
	JPanel p8=new JPanel(new GridLayout(1,3));
	p8.setOpaque(false);
	JPanel p9=new JPanel(new GridLayout(1,3));
	p9.setOpaque(false);
	JPanel p10=new JPanel(new GridLayout(1,3));
	p10.setOpaque(false);
	l[0]=new JLabel("Search by Id");
    l[0].setFont(new Font("Serif",Font.BOLD,20));
    f[0]=new JTextField(10);
    l[1]=new JLabel("Search by type");
    l[1].setFont(new Font("Serif",Font.BOLD,20));
    f[1]=new JTextField(10);
    l[2]=new JLabel("Search by Department");
    l[2].setFont(new Font("Serif",Font.BOLD,20));
    f[2]=new JTextField(10);
    l[3]=new JLabel("Search by Speciality");
    l[3].setFont(new Font("Serif",Font.BOLD,20));
    f[3]=new JTextField(10);
    for(int i=0;i<4;i++){
    	b[i]=new JButton("Search");
    }
    for(int i=12;i<20;i++){
    	lb[i]=new JLabel("                           ");
    }
    p10.add(lb[18]);
    p10.add(b[3]);
    p10.add(lb[19]);
    p9.add(lb[16]);
    p9.add(b[2]);
    p9.add(lb[17]);
    p8.add(lb[14]);
    p8.add(b[1]);
    p8.add(lb[15]);
    p7.add(lb[12]);
    p7.add(b[0]);
    p7.add(lb[13]);
    p1.add(l[2]);
    p1.add(f[2]);
    p2.add(l[1]);
    p2.add(f[1]);
    p3.add(l[0]);
    p3.add(f[0]);
    p4.add(l[3]);
    p4.add(f[3]);
   p.add(lb[1]);
    p.add(p3);
    p.add(lb[2]);
    p.add(p7);
    p.add(lb[3]);
    p.add(p2);
    p.add(lb[4]);
    p.add(p8);
    p.add(lb[5]);
    p.add(p1);
    p.add(lb[6]);
    p.add(p9);
    p.add(lb[7]);
    p.add(p4);
    p.add(lb[8]);
    p.add(p10);
    p.add(lb[9]);
    for(int i=10;i<12;i++){
    	lb[i]=new JLabel("                                                                                                                    ");
    }
    p5.add(lb[10]);
    p6.add(lb[11]);
    this.add(p,BorderLayout.CENTER);
    this.add(panel,BorderLayout.NORTH);
    this.add(p5,BorderLayout.EAST);
    this.add(p6,BorderLayout.WEST);
    this.setSize(1350,720);
    validate();
    MyButton5 butt=new MyButton5();
    b[0].addActionListener(butt);
    b[1].addActionListener(butt);
    b[2].addActionListener(butt);
    b[3].addActionListener(butt);
    b1.addActionListener(butt);
}
public class MyButton5 implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1){
			dispose();
		}
		if(e.getSource()==b[0]){
			doctor s;
			try {
				ObjectInputStream x = new ObjectInputStream(new FileInputStream("doctor.ser"));
				while (true) {
					s = (doctor) x.readObject();
					if (s.getDocId().equals(f[0].getText())) {
						doctor_info df=new doctor_info();
						df.setDoctorId(s.getDocId());
						df.setDoctorName(s.getName());
						df.setDoctorAge(s.getAge());
						df.setDoctorGender(s.getGender());
						df.setDoctorDOB(s.getDOB());
						df.setDoctorDep(s.getDepartment());
						df.setDoctorQualiiaction(s.getQualification());
						df.setDoctorNum(s.getNum());
						df.setDoctorAddress(s.getAddress());
						df.setDoctorHireDate(s.getHireDate());
						df.setDoctorTiming(s.getTimings());
						df.setDoctorType(s.getType());
						df.setDoctorStaffType(s.getStaffType());
						df.setDoctorSep(s.getSpeciality());
						df.setVisible(true);
						break;
					}
				}
				f[0].setText(null);
			}catch(Exception exp){
				return;
			}
		}
		if(e.getSource()==b[1]){
			File newTextFile=new File("new.txt");
			try {
				FileWriter fw=new FileWriter(newTextFile);
				 ArrayList<doctor> doctorList = readAllData() ;
				   for(int i = 0 ; i<doctorList.size() ; i++){
					if (doctorList.get(i).getType().equalsIgnoreCase(f[1].getText())) {
						fw.write("Id:");
						fw.write(doctorList.get(i).getDocId());
						fw.write('\n');
						fw.write("Name:");
						fw.write(doctorList.get(i).getName());
						fw.write('\n');
						fw.write("Date of Birth:");
						fw.write(doctorList.get(i).getDOB());
						fw.write('\n');
						fw.write("Age:");
						fw.write(doctorList.get(i).getAge());
						fw.write('\n');
						fw.write("Gender:");
						fw.write(doctorList.get(i).getGender());
						fw.write('\n');
						fw.write("Department:");
						fw.write(doctorList.get(i).getDepartment());
						fw.write('\n');
						fw.write("Education:");
						fw.write(doctorList.get(i).getEducation());
						fw.write('\n');
						fw.write("Phone Number:");
						fw.write(doctorList.get(i).getNum());
						fw.write('\n');
						fw.write("Timings:");
						fw.write(doctorList.get(i).getTimings());
						fw.write('\n');
						fw.write("Indoor/Outdoor:");
						fw.write(doctorList.get(i).getType());
						fw.write('\n');
						fw.write(".....................................end..................................");
						fw.write('\n');
					}
				}
				   f[1].setText(null);
				fw.close();
	          JFrame f=new JFrame();
	          f.setLayout(new BorderLayout());
	          JTextArea fe=new JTextArea();
	          fe.setLineWrap(true);
	          fe.setWrapStyleWord(true);
	          JScrollPane sp=new JScrollPane(fe);
	          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	          f.add(sp,BorderLayout.CENTER);
	        
	        FileReader reader=new FileReader("new.txt");
	        BufferedReader br=new BufferedReader(reader);
	        fe.read(br,null);
	         br.close();
	         fe.requestFocus();
	         f.setVisible(true);
	         f.setSize(500,500);
	         
			}catch(Exception exp){
				return;
			}
		}
		if(e.getSource()==b[2])
		{
			File newTextFile=new File("new.txt");
			try {
				FileWriter fw=new FileWriter(newTextFile);
				 ArrayList<doctor> doctorList = readAllData() ;
				   for(int i = 0 ; i<doctorList.size() ; i++){
					if (doctorList.get(i).getDepartment().equalsIgnoreCase(f[2].getText())) {
						fw.write("Id:");
						fw.write(doctorList.get(i).getDocId());
						fw.write('\n');
						fw.write("Name:");
						fw.write(doctorList.get(i).getName());
						fw.write('\n');
						fw.write("Date of Birth:");
						fw.write(doctorList.get(i).getDOB());
						fw.write('\n');
						fw.write("Age:");
						fw.write(doctorList.get(i).getAge());
						fw.write('\n');
						fw.write("Gender:");
						fw.write(doctorList.get(i).getGender());
						fw.write('\n');
						fw.write("Department:");
						fw.write(doctorList.get(i).getDepartment());
						fw.write('\n');
						//fw.write(doctorList.get(i).getGender());
						//fw.write('\n');
						fw.write("Education:");
						fw.write(doctorList.get(i).getEducation());
						fw.write('\n');
						fw.write("Phone Number:");
						fw.write(doctorList.get(i).getNum());
						fw.write('\n');
						fw.write("Timings:");
						fw.write(doctorList.get(i).getTimings());
						fw.write('\n');
						fw.write("Indoor/Outdoor:");
						fw.write(doctorList.get(i).getType());
						fw.write('\n');
						fw.write(".....................................end..................................");
						fw.write('\n');
					}
				}
				   f[2].setText(null);
				fw.close();
	          JFrame f=new JFrame();
	          f.setLayout(new BorderLayout());
	          JTextArea fe=new JTextArea();
	          fe.setLineWrap(true);
	          fe.setWrapStyleWord(true);
	          JScrollPane sp=new JScrollPane(fe);
	          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	          f.add(sp,BorderLayout.CENTER);
	        
	        FileReader reader=new FileReader("new.txt");
	        BufferedReader br=new BufferedReader(reader);
	        fe.read(br,null);
	         br.close();
	         fe.requestFocus();
	         f.setVisible(true);
	         f.setSize(500,500);
			}catch(Exception exp){
				return;
			}
		}
		if(e.getSource()==b[3])
		{
			File newTextFile=new File("new.txt");
			try {
				FileWriter fw=new FileWriter(newTextFile);
				 ArrayList<doctor> doctorList = readAllData() ;
				   for(int i = 0 ; i<doctorList.size() ; i++){
					if (doctorList.get(i).getSpeciality().equalsIgnoreCase(f[3].getText())) {
						fw.write("Id:");
						fw.write(doctorList.get(i).getDocId());
						fw.write('\n');
						fw.write("Name:");
						fw.write(doctorList.get(i).getName());
						fw.write('\n');
						fw.write("Date of Birth:");
						fw.write(doctorList.get(i).getDOB());
						fw.write('\n');
						fw.write("Age:");
						fw.write(doctorList.get(i).getAge());
						fw.write('\n');
						fw.write("Gender:");
						fw.write(doctorList.get(i).getGender());
						fw.write('\n');
						fw.write("Department:");
						fw.write(doctorList.get(i).getDepartment());
						fw.write('\n');
						//fw.write(doctorList.get(i).getGender());
						//fw.write('\n');
						fw.write("Education:");
						fw.write(doctorList.get(i).getEducation());
						fw.write('\n');
						fw.write("Phone Number:");
						fw.write(doctorList.get(i).getNum());
						fw.write('\n');
						fw.write("Timings:");
						fw.write(doctorList.get(i).getTimings());
						fw.write('\n');
						fw.write("Indoor/Outdoor:");
						fw.write(doctorList.get(i).getType());
						fw.write('\n');
						fw.write(".....................................end..................................");
						fw.write('\n');
					}
				}
				   f[3].setText(null);
				fw.close();
	          JFrame f=new JFrame();
	          f.setLayout(new BorderLayout());
	          JTextArea fe=new JTextArea();
	          fe.setLineWrap(true);
	          fe.setWrapStyleWord(true);
	          JScrollPane sp=new JScrollPane(fe);
	          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	          f.add(sp,BorderLayout.CENTER);
	        
	        FileReader reader=new FileReader("new.txt");
	        BufferedReader br=new BufferedReader(reader);
	        fe.read(br,null);
	         br.close();
	         fe.requestFocus();
	         f.setVisible(true);
	         f.setSize(500,500);
			}catch(Exception exp){
				return;
			}
		}
		}
                    
	}
public ArrayList<doctor>  readAllData ()
{
  //  ArrayList initialized with size 0
ArrayList<doctor> doctorList = new ArrayList<doctor>(0);
//Input stream
ObjectInputStream inputStream = null;
try
{
//open file for reading
inputStream = new ObjectInputStream(new FileInputStream("doctor.ser"));
//End Of File flag
boolean EOF = false;
//Keep reading file until file ends
while(!EOF) {
try {
// read object and type cast into CarDetails object
doctor myObj = (doctor) inputStream.readObject();
// add object into ArrayList
doctorList.add(myObj);
//System.out.println("Read: " + myObj.getName());
} catch (ClassNotFoundException e) {
//System.out.println("Class not found");
} catch (EOFException end) {
// EOFException is raised when file ends
// set End Of File flag to true so that loop exits
EOF = true;
}
}
} catch(FileNotFoundException e) {
//System.out.println("Cannot find file");
} catch (IOException e) {
//System.out.println("IO Exception while opening stream");
//e.printStackTrace();
} finally { // cleanup code to close stream if it was opened
try {
if(inputStream != null)
inputStream.close( );
} catch (IOException e) {
//TODO Auto-generated catch block
System.out.println("IO Exception while closing file");
}
}
//returns ArrayList
return doctorList;
}              
	}
