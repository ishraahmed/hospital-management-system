package view;
import java.io.*;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import model.administrator;
import model.patient;
import model.technicalStaff;
import model.workers_staff;
public class searchView_worker extends JFrame {
	JLabel l;
	JLabel l1;
	JLabel l2;
	JLabel l3;
	JLabel l4;
	JLabel[] lb=new JLabel[15];
	JTextField f;
	JButton sub;
	public searchView_worker(){
		super("Workers Staff");
		setContentPane(new JLabel(new ImageIcon("image5.jpg")));
		l4=new JLabel("          Workers Search");
		l4.setFont(new Font("ALGERIAN",Font.BOLD,30));
		this.setLayout(new BorderLayout());
		JPanel p=new JPanel(new GridLayout(5,2));
		p.setOpaque(false);
		JPanel p1=new JPanel(new GridLayout(8,0));
		p1.setOpaque(false);
		JPanel p2=new JPanel(new BorderLayout());
		p2.setOpaque(false);
		l=new JLabel("              Enter Worker's Id");
		l.setFont(new Font("serif",Font.BOLD,15));
		f=new JTextField(10);
		sub=new JButton("Search");
		l1=new JLabel(" ");
		l2=new JLabel(" ");
		for(int i=0;i<15;i++){
			lb[i]=new JLabel("                                     ");
		}
		p.add(lb[0]);
		p.add(lb[1]);
		p.add(lb[7]);
		p.add(lb[8]);
		p.add(l);
		p.add(f);
		p.add(l1);
		p.add(l2);
		p.add(lb[2]);
		p.add(lb[3]);
		p1.add(p2);
		p1.add(lb[9]);
		p1.add(lb[10]);
		p1.add(lb[11]);
		p1.add(lb[12]);
		p1.add(lb[13]);
		p1.add(lb[14]);
		p2.add(sub,BorderLayout.CENTER);
		p2.add(lb[5],BorderLayout.EAST);
		p2.add(lb[6],BorderLayout.WEST);
		p1.add(lb[4]);
		this.add(p,BorderLayout.CENTER);
		this.add(p1,BorderLayout.SOUTH);
		l3=new JLabel("                    ");
		this.add(l3,BorderLayout.EAST);
		this.add(l4,BorderLayout.NORTH);
		this.setSize(500,500);
		this.setVisible(true);
		MyButton4 butt=new MyButton4();
		sub.addActionListener(butt);
	}
	class MyButton4 implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==sub){
				ObjectInputStream inputStream=null;
				workers_staff ad;
				try{
					inputStream=new ObjectInputStream(new FileInputStream("worker.ser"));
					while(true){
						ad=(workers_staff)inputStream.readObject();
						if(ad.getId().equals(f.getText())){
							workers_info ti=new workers_info();
							ti.setWorkerId(ad.getId());
							ti.setWorkerName(ad.getName());
							ti.setWorkerDOB(ad.getDOB());
							ti.setWorkerAge(ad.getAge());
							ti.setWorkerGender(ad.getGender());
							ti.setWorkerHireDate(ad.getHireDate());
							ti.setWorkerNumber(ad.getNum());
							ti.setWorkerSalary(ad.getStaffType());
							ti.setWorkerAddress(ad.getAddress());
							ti.setWorkerEducation(ad.getEducation());
							ti.setWorkerStaffType(ad.getType());
							ti.setVisible(true);
							f.setText(null);
						}
					}
				}
				catch(Exception exp){
					return;
				}
				
			}
		}}
	public ArrayList<workers_staff> readAllData(){
		ArrayList<workers_staff> workerList=new ArrayList<workers_staff>(0);
		ObjectInputStream inputStream=null;
		try{
			inputStream=new ObjectInputStream(new FileInputStream("worker.ser"));
			Boolean EOF=false;
			while(!EOF){
				try{
					workers_staff obj=(workers_staff)inputStream.readObject();
					workerList.add(obj);
					
				}
				catch (ClassNotFoundException e) {
					//System.out.println("Class not found");
					} catch (EOFException end) {
					// EOFException is raised when file ends
					// set End Of File flag to true so that loop exits
					EOF = true;
					}
			}
		}
		catch(FileNotFoundException e) {
			//System.out.println("Cannot find file");
			} catch (IOException e) {
			//System.out.println("IO Exception while opening stream");
			//e.printStackTrace();
			}finally { // cleanup code to close stream if it was opened
				try {
					if(inputStream != null)
					inputStream.close( );
					} catch (IOException e) {
					// TODO Auto-generated catch block
					System.out.println("IO Exception while closing file");
					}
					}
		return workerList;
	}	
}