package view;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import control.login_control;
import model.login;
public class administrator_view extends JFrame {
JLabel[] l=new JLabel[12];
JLabel[] lp=new JLabel[24];
JLabel e;
JLabel w;
JTextField[] f=new JTextField[12];
JButton[] b=new JButton[7];
JRadioButton[] rb=new JRadioButton[2];
ButtonGroup  g=new ButtonGroup();
public administrator_view(){
	super("Administrator");
	setContentPane(new JLabel(new ImageIcon("image1.jpg")));
	rb[0]=new JRadioButton("male",true);
	rb[1]=new JRadioButton("female",false);
	g.add(rb[0]);
	g.add(rb[1]);
	JPanel ppp=new JPanel(new GridLayout(1,2));
	//ppp.setOpaque(false);
	ppp.add(rb[0]);
	ppp.add(rb[1]);
	ppp.setOpaque(false);
	l[0]=new JLabel("                                        Administrator Record");
	l[0].setFont(new Font("ALGERIAN",Font.BOLD,35));
	l[1]=new JLabel("                                                                   ");
	b[0]=new JButton("Home");
	b[1]=new JButton("Logout");
	b[2]=new JButton("Back");
	b[3]=new JButton("Save");
	b[4]=new JButton("Search");
	b[5]=new JButton("Edit");
	b[6]=new JButton("Delete");
	l[2]=new JLabel("     Administrator Id");
	l[2].setFont(new Font("Serif",Font.BOLD,20));
	l[3]=new JLabel("                      Name");
	l[3].setFont(new Font("Serif",Font.BOLD,20));
	l[4]=new JLabel("     Date of Birth");
	l[4].setFont(new Font("Serif",Font.BOLD,20));
	l[5]=new JLabel("                      Age");
	l[5].setFont(new Font("Serif",Font.BOLD,20));
	l[6]=new JLabel("     Gender");
	l[6].setFont(new Font("Serif",Font.BOLD,20));
	l[7]=new JLabel("                      Education");
	l[7].setFont(new Font("Serif",Font.BOLD,20));
	l[8]=new JLabel("      Hire Date");
	l[8].setFont(new Font("Serif",Font.BOLD,20));
	l[9]=new JLabel("                      Number");
	l[9].setFont(new Font("Serif",Font.BOLD,20));
	l[10]=new JLabel("     Address");
	l[10].setFont(new Font("Serif",Font.BOLD,20));
	l[11]=new JLabel("                       Salary");
	l[11].setFont(new Font("Serif",Font.BOLD,20));
	for(int i=0;i<12;i++){
		f[i]=new JTextField(10);
	}
	for(int i=0;i<24;i++){
		lp[i]=new JLabel("       ");
	}
	JPanel p=new JPanel();
//	p.setOpaque(false);
	p.add(l[0]);
	p.add(l[1]);
	p.add(b[0]);
	p.add(b[1]);
	p.add(b[2]);
	p.setOpaque(false);
	JPanel p1=new JPanel(new GridLayout(11,4));
	//p1.setOpaque(false);
	for(int i=0;i<4;i++){
		p1.add(lp[i]);
	}
	p1.add(l[2]);
	p1.add(f[0]);
	p1.add(l[3]);
	p1.add(f[1]);
	for(int i=4;i<8;i++){
		p1.add(lp[i]);
	}
	p1.add(l[4]);
	p1.add(f[2]);
	p1.add(l[5]);
	p1.add(f[3]);
	for(int i=8;i<12;i++){
		p1.add(lp[i]);
	}
	p1.add(l[6]);
	
	p1.add(ppp);
	p1.add(l[7]);
	p1.add(f[5]);
	for(int i=12;i<16;i++){
		p1.add(lp[i]);
	}
	p1.add(l[8]);
	p1.add(f[6]);
	p1.add(l[9]);
	p1.add(f[7]);
	for(int i=16;i<20;i++){
		p1.add(lp[i]);
	}
	p1.add(l[10]);
	p1.add(f[8]);
	p1.add(l[11]);
	p1.add(f[9]);
	for(int i=20;i<24;i++){
		p1.add(lp[i]);
	}
	p1.setOpaque(false);
	JPanel p2=new JPanel();
	//p2.setOpaque(false);
	p2.add(b[3]);
p2.add(b[4]);
p2.add(b[5]);
p2.add(b[6]);
p2.setOpaque(false);
JPanel p3=new JPanel();
e=new JLabel("                                          ");
p3.add(e);
p3.setOpaque(false);
JPanel p4=new JPanel();
w=new JLabel("                             ");
p4.add(w);
p4.setOpaque(false);
setLayout(new BorderLayout());
this.add(p,BorderLayout.NORTH);
this.add(p1,BorderLayout.CENTER);
this.add(p2,BorderLayout.SOUTH);
this.add(p3,BorderLayout.EAST);
this.add(p4,BorderLayout.WEST);
this.setSize(1350,720);
MyButton butt=new MyButton();
b[0].addActionListener(butt);
b[1].addActionListener(butt);
b[2].addActionListener(butt);
}
public String getAdminId(){
	return f[0].getText();
}
public void setAdminId(String i){
	f[0].setText(i);
}
public String getAdminName(){
	return f[1].getText();
}
public void setAdminName(String i){
	f[1].setText(i);
}
public String getAdminDOB(){
	return f[2].getText();
}
public void setAdminDOB(String i){
	f[2].setText(i);
}
public String getAdminAge(){
	return f[3].getText();
}
public void setAdminAge(String i){
	f[3].setText(i);
}
public String getAdminGender(){
	if(rb[0].isSelected())
		return "male";
	else if(rb[0].isSelected())
		return "female";
	else
		return " ";
}
/*public void setAdminGender(String i){
	f[4].setText(i);
}*/
public String getAdminEducation(){
	return f[5].getText();
}
public void setAdminEducation(String i){
	f[5].setText(i);
}
public String getAdminHireDate(){
	return f[6].getText();
}
public void setAdminHireDate(String i){
	f[6].setText(i);
}
public String getAdminNumber(){
	return f[7].getText();
}
public void setAdminNumber(String i){
	f[7].setText(i);
}
public String getAdminAddress(){
	return f[8].getText();
}
public void setAdminAddress(String i){
	f[8].setText(i);
}
public String getAdminSalary(){
	return f[9].getText();
}
public void setAdminSalary(String i){
	f[9].setText(i);
}
public void AddAdminSave(ActionListener e){
	b[3].addActionListener(e);
}
public void AddAdminSearch(ActionListener e){
	b[4].addActionListener(e);
}
public void AddAdminEdit(ActionListener e){
	b[5].addActionListener(e);
}
public void AddAdminDelete(ActionListener e){
	b[6].addActionListener(e);
}
class MyButton implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
	if(e.getSource()==b[0]){
		dispose();
		frame f=new frame();
		f.setVisible(true);
	}
	if(e.getSource()==b[1]){
		dispose();
		login l=new login();
		login_view lv=new login_view();
		login_control lc=new login_control(l,lv);
		lv.setVisible(true);
	}
	if(e.getSource()==b[2]){
		dispose();
		frame f=new frame();
		f.setVisible(true);
	}
		
	}
	
	
}
}
