package view;

import java.awt.BorderLayout;


import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.*;

import javax.swing.*;



import java.io.*;

public class patient_info extends JFrame implements Serializable {
	JLabel l;
	JTextField f;
	JLabel l1;
	JTextField f1;
	JLabel l2;
	JTextField f2;
	JLabel l3;
	JTextField f3;
	JLabel l4;
	JTextField f4;
	JLabel l5;
	JTextField f5;
	JLabel l6;
	JTextField f6;
	JLabel l7;
	JTextField f7;
	JLabel l8;
	JTextField f8;
	JLabel l9;
	JTextField f9;
	JLabel l10;
	JTextField f10;
	JLabel l11;
	JTextField f11;
	JLabel l12;
	JTextField f12;
	JLabel l13;
	JTextField f13;
	JLabel[] ll=new JLabel[9];
	JButton[] bb=new JButton[1]; 
	public patient_info(){
		super("Patient");
		setContentPane(new JLabel(new ImageIcon("image1.jpg")));
		l=new JLabel("                             Name");
		l.setFont(new Font("serif",Font.BOLD,20));
		f=new JTextField(10);
		l1=new JLabel("                                 Age");
		l1.setFont(new Font("serif",Font.BOLD,20));
		f1=new JTextField(10);
		l2=new JLabel("                       Gender");
		l2.setFont(new Font("serif",Font.BOLD,20));
		f2=new JTextField(10);
		l3=new JLabel("                       Date of birth");
		l3.setFont(new Font("serif",Font.BOLD,20));
		f3=new JTextField(10);
		l4=new JLabel("                       Patient's id");
		l4.setFont(new Font("serif",Font.BOLD,20));
		f4=new JTextField(10); 
		l5=new JLabel("                            Date of visit");
		l5.setFont(new Font("serif",Font.BOLD,20));
		f5=new JTextField(10);
		l6=new JLabel("                       Consultant");
		l6.setFont(new Font("serif",Font.BOLD,20));
		f6=new JTextField(10);
		l7=new JLabel("                  Consultant's department");
		l7.setFont(new Font("serif",Font.BOLD,20));
		f7=new JTextField(10);
		l8=new JLabel("                       Date of Admitance");
		l8.setFont(new Font("serif",Font.BOLD,20));
		f8=new JTextField(10);
		l9=new JLabel("                            Room no");
		l9.setFont(new Font("serif",Font.BOLD,20));
		f9=new JTextField(10);
		l10=new JLabel("                      Ward");
		l10.setFont(new Font("serif",Font.BOLD,20));
		f10=new JTextField(10);
		l11=new JLabel("                            Bed no");
		f11=new JTextField(10);
		l11.setFont(new Font("serif",Font.BOLD,20));
		l12=new JLabel("                      Discharge Date");
		l12.setFont(new Font("serif",Font.BOLD,20));
		f12=new JTextField(10);
		JPanel p=new JPanel();
		JPanel[] p1=new JPanel[4];
		p.setOpaque(false);
		p1[0]=new JPanel();
		p1[0].setOpaque(false);
		ll[0]=new JLabel("                                         Patient' Information");
		ll[0].setFont(new Font("ALGERIAN",Font.BOLD,35));
		ll[1]=new JLabel("                                                                                                  ");
		bb[0]=new JButton("Back");
		p1[0].add(ll[0]);
		p1[0].add(ll[1]);
		p1[0].add(bb[0]);
		p1[1]=new JPanel();
		p1[1].setOpaque(false);
		ll[2]=new JLabel("   ");
		p1[1].add(ll[2]);
		ll[3]=new JLabel("                  ");
		ll[4]=new JLabel("      ");
		p1[2]=new JPanel();
		p1[3]=new JPanel();
		p1[2].setOpaque(false);
		p1[3].setOpaque(false);
		p1[2].add(ll[3]);
		p1[3].add(ll[4]);
		for(int i=5;i<9;i++){
			ll[i]=new JLabel("  ");
		}
		p.setLayout(new GridLayout(8,4));
		for(int i=5;i<9;i++){
			p.add(ll[i]);
		}
		p.add(l4);
		p.add(f4);
		p.add(l);
		p.add(f);
		p.add(l3);
		p.add(f3);
		p.add(l1);
		p.add(f1);
		p.add(l2);
		p.add(f2);
		p.add(l5);
		p.add(f5);
		p.add(l6);
		p.add(f6);
		p.add(l7);
		p.add(f7);
		p.add(l8);
		p.add(f8);
		p.add(l9);
		p.add(f9);
		p.add(l10);
		p.add(f10);
		p.add(l11);
		p.add(f11);
		p.add(l12);
		p.add(f12);
		l13=new JLabel("                             Bill");
		f13=new JTextField(10);
		l13.setFont(new Font("serif",Font.BOLD,20));
		p.add(l13);
		p.add(f13);
		this.setLayout(new BorderLayout());
		this.add(p,BorderLayout.CENTER);
		this.add(p1[0],BorderLayout.NORTH);
		this.add(p1[1],BorderLayout.SOUTH);
		this.add(p1[2],BorderLayout.EAST);
		this.add(p1[3],BorderLayout.WEST);
		this.add(p);
		this.setSize(1350,720);
		MyButton butt=new MyButton();
		bb[0].addActionListener(butt);
	}
	class MyButton implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==bb[0]){
				dispose();
			}
			
		}
		
	}
	public void setName(String i){
		f.setText(i);
	}
	public void setAge(String i){
		f1.setText(i);
	}
	public void setGender(String i){
		f2.setText(i);
	}
	public void setDOB(String i){
		f3.setText(i);
	}
	public void setId(String i){
		f4.setText(i);
	}
	public void setDOV(String i){
		f5.setText(i);
	}
	public void setConsultant(String i){
		f6.setText(i);
	}
	public void setConsultantDep(String i){
		f7.setText(i);
	}
	public void setDOA(String i){
		f8.setText(i);
	}
	public void setWard(String i){
		f9.setText(i);
	}
	public void setRoom(String i){
		f10.setText(i);
	}
	public void setBed(String i){
		f11.setText(i);
	}
	public void setDischargeDate(String i){
		f12.setText(i);
	}
	public void setBill(String i){
		f13.setText(i);
	}
}
