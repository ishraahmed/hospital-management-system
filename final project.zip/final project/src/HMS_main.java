
import model.login;
import view.login_view;
import control.login_control;
public class HMS_main {
public static void main(String args[]){
	login l=new login();
	login_view lv=new login_view();
	login_control login=new login_control(l,lv);
	lv.setVisible(true);
}
}

