package model;

public class staff extends person implements salary {
private String hireDate;
private String bill;

public staff() {
	super();
	// TODO Auto-generated constructor stub
}
public staff(String name, String age, String gender, String dOB,String hD,String sT) {
	super(name, age, gender, dOB);
	hireDate=hD;
	bill=sT;
}
public String getHireDate() {
	return hireDate;
}
public void setHireDate(String hireDate) {
	this.hireDate = hireDate;
}
public String getStaffType() {
	return bill;
}
public void setStaffType(String staffType) {
	this.bill = staffType;
}

}
