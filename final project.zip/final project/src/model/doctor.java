package model;
import java.io.Serializable;
public class doctor extends staff implements Serializable {
private String docId;
private String qualification;
private String speciality;
private String type;
private String timings;
private String department;
private String num;
private String address;
public doctor(){}
public doctor(String name, String age, String gender, String dOB,String hD,String st,String doci,String education1,String sep,String type1,String timings1,String dep,String num1,String address1) {
	super(name, age, gender, dOB,hD,st);
	docId=doci;
	num=num1;
	address=address1;
	qualification=education1;
	speciality=sep;
	type=type1;
	timings=timings1;
	department=dep;
}
public String getDocId() {
	return docId;
}
public void setDocId(String docId) {
	this.docId = docId;
}
public String getEducation() {
	return qualification;
}
public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public String getNum() {
	return num;
}
public void setNum(String num) {
	this.num = num;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public void setEducation(String education) {
	this.qualification = education;
}
public String getSpeciality() {
	return speciality;
}
public void setSpeciality(String speciality) {
	this.speciality = speciality;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getTimings() {
	return timings;
}
public void setTimings(String timings) {
	this.timings = timings;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}

}

