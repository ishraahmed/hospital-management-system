package model;

public class workers_staff extends staff{
private String id;
private String num;
private String address;
private String education;
private String type;
public workers_staff() {
	super();
	// TODO Auto-generated constructor stub
}
public workers_staff(String name, String age, String gender, String dOB, String hD, String sT,String i,String num1,String address1,String education1,String type1) {
	super(name, age, gender, dOB, hD, sT);
	id=i;
	num=num1;
	address=address1;
	education=education1;
	type=type1;
}
public String getId() {
	return id;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public void setId(String id) {
	this.id = id;
}
public String getNum() {
	return num;
}
public void setNum(String num) {
	this.num = num;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getEducation() {
	return education;
}
public void setEducation(String education) {
	this.education = education;
}

}
