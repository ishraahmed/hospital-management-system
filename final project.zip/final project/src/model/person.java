package model;
import java.io.Serializable;
public class person implements Serializable{
private String name;
private String age;
private String gender;
private String DOB;
person(){}
public person(String name, String age, String gender, String dOB) {
	super();
	this.name = name;
	this.age = age;
	this.gender = gender;
	DOB = dOB;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getDOB() {
	return DOB;
}
public void setDOB(String dOB) {
	DOB = dOB;
}

}
