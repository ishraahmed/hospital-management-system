package model;

public interface salary {
public String bill=null;
}
