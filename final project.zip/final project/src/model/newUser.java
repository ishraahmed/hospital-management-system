package model;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class newUser extends login implements Serializable{
private String question1;
private String question2;
public newUser(){
	super();
}
public newUser(String username, String password,String q1,String q2) {
	super(username, password);
	question1=q1;
	question2=q2;
}
public String getQuestion1() {
	return question1;
}
public void setQuestion1(String question1) {
	this.question1 = question1;
}
public String getQuestion2() {
	return question2;
}
public void setQuestion2(String question2) {
	this.question2 = question2;
}
public String getUsername(){
	return super.getUsername();
}
public String getPassword(){
	return super.getPassword();
}
}

