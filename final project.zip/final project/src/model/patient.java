package model;
import java.io.Serializable;
public class patient extends person implements Serializable,salary{
private String patientId;
private String DOV;
private doctor consultant;
private String bill;
private String dischargeDate;
private String consultantdep;
private String DOA;
private String room;
private String ward;
private String bed;
public patient() {
	super();
	// TODO Auto-generated constructor stub
}
public patient(String name, String age, String gender, String dOB,String patientID1,String dov1,doctor doc,String a,String b,String c,String d,String bill1,String dis) {
	super(name, age, gender, dOB);
	// TODO Auto-generated constructor stub
	patientId=patientID1;
	DOV=dov1;
	consultant=doc;
	DOA=a;
	room=b;
	ward=c;
	bed=d;
	bill=bill1;
	dischargeDate=dis;
}
public String getDOA() {
	return DOA;
}
public void setDOA(String dOA) {
	DOA = dOA;
}
public String getRoom() {
	return room;
}
public void setRoom(String room) {
	this.room = room;
}
public String getWard() {
	return ward;
}
public void setWard(String ward) {
	this.ward = ward;
}
public String getBed() {
	return bed;
}
public void setBed(String bed) {
	this.bed = bed;
}
public String getBill() {
	return bill;
}
public void setBill(String bill) {
	this.bill = bill;
}
public String getDischargeDate() {
	return dischargeDate;
}
public void setDischargeDate(String dischargeDate) {
	this.dischargeDate = dischargeDate;
}
public void setConsultant(doctor consultant) {
	this.consultant = consultant;
}
public void setConsultantdep(String consultantdep) {
	this.consultantdep = consultantdep;
}
public String getPatientId() {
	return patientId;
}
public void setPatientId(String patientId) {
	this.patientId = patientId;
}
public String getDOV() {
	return DOV;
}
public void setDOV(String dOV) {
	DOV = dOV;
}
public String getConsultant() {
	return consultant.getName();
}
public String getConsultantdep() {
	return consultant.getDepartment();
}


}

